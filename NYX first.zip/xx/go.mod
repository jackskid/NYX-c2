module apex2

go 1.24.0

require (
	github.com/refraction-networking/utls v1.8.1
	golang.org/x/crypto v0.46.0
	golang.org/x/term v0.39.0
)

require (
	github.com/andybalholm/brotli v1.0.6 // indirect
	github.com/klauspost/compress v1.17.4 // indirect
	golang.org/x/sys v0.40.0 // indirect
)
