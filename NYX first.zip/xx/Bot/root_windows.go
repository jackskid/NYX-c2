//go:build windows

package main

func isRoot() bool {
	return false
}

func ensureRoot() {
	// Windows-on nincs root koncepció
}